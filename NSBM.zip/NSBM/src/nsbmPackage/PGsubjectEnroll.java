/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class PGsubjectEnroll {
    private String faculty,course,month,pgid,subjcode;
    private int year,semester,credits;
    private double fees;
    
        public PGsubjectEnroll(String faculty, String course, String month, int year, int semester, String pgid, String subjcode, int credits, double fees) {
         this.faculty = faculty;
        this.course = course;
        this.month = month;
        this.year = year;
        this.semester = semester;
        this.pgid = pgid;
        this.subjcode = subjcode;
        this.credits = credits;
        this.fees = fees;
    }

    public String getFaculty() {
        return faculty;
    }

    public String getCourse() {
        return course;
    }

    public String getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public int getSemester() {
        return semester;
    }

    public String getPgid() {
        return pgid;
    }

    public String getSubjcode() {
        return subjcode;
    }

    public int getCredits() {
        return credits;
    }

    public double getFees() {
        return fees;
    }


}
