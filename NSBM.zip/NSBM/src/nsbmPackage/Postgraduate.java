/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

import com.sun.org.apache.xalan.internal.xsltc.compiler.util.StringStack;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableModel;

/**
 *
 * @author User
 */
public class Postgraduate extends javax.swing.JFrame {

    String gender;
    public Postgraduate() {
        this.setResizable(false);
        this.setVisible(true);
        initComponents();
        Toolkit tk=getToolkit();
        this.setSize((int)tk.getScreenSize().getWidth(),(int)tk.getScreenSize().getHeight());
        //showPGSubjEnroll();
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        btnEnrollConfirm.setVisible(false);
        txtC.setVisible(false);
        txtDob.setFont(new Font("Century Gothic", Font.PLAIN, 18));
        JTableHeader header = ugTable.getTableHeader();
        header.setFont(new Font("Century Gothic", Font.PLAIN, 16));
        JTableHeader header2 = tableSubject.getTableHeader();
        header2.setFont(new Font("Century Gothic", Font.PLAIN, 16));
        JTableHeader header3 = tableUGsubj.getTableHeader();
        header3.setFont(new Font("Century Gothic", Font.PLAIN, 16));
        JTableHeader header4 = tableUgResult.getTableHeader();
        header4.setFont(new Font("Century Gothic", Font.PLAIN, 16));
    }
    public ArrayList<PGstudents> userList(){
        ArrayList<PGstudents> pgList=new ArrayList<>();
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           String val5;
           val5=comboViewCourse.getSelectedItem().toString();
           String query1="SELECT * FROM pgstudents where course='"+val5+"' ";
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(query1);
           PGstudents u;
           while(rs.next()){
               u=new PGstudents(rs.getString("course"),rs.getString("pgid"),rs.getString("name"),rs.getString("dob"),rs.getString("gender"),rs.getString("address"),rs.getString("email"),rs.getString("quatype"),rs.getString("institute"),rs.getInt("tpno"),rs.getInt("yearcomplete"));
               pgList.add(u);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Error in viewing students");
        }
        return pgList;
    }
     public void showPGstudents(){
          // to insert database values into jtable
        ArrayList<PGstudents> uList=userList();
        DefaultTableModel model=(DefaultTableModel) ugTable.getModel();
        Object[] row=new Object[10];
        for(int i=0;i<uList.size();i++){
           
            row[0]=uList.get(i).getPgid();
            row[1]=uList.get(i).getName();
            row[2]=uList.get(i).getDob();
            row[3]=uList.get(i).getGender();
            row[4]=uList.get(i).getAddress();
            row[5]=uList.get(i).getTpno();
            row[6]=uList.get(i).getEmail();
            row[7]=uList.get(i).getQuatype();
            row[8]=uList.get(i).getInstitute();
            row[9]=uList.get(i).getYearcomplete();
            model.addRow(row);
        }
    }
     public ArrayList<PGsubj> subjList(){
        ArrayList<PGsubj> subjList=new ArrayList<>();
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           
           String val1;
           val1=comboCourse.getSelectedItem().toString();
           String val2;
           val2=comboYear.getSelectedItem().toString();
           String val3;
           val3=comboSemester.getSelectedItem().toString();
           
           //to fill up the subjects for specific course under specific year
           String query1="SELECT * FROM subject where course='"+val1+"' and year='"+val2+"' ";
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(query1);
           PGsubj u;
           while(rs.next()){
               u=new PGsubj(rs.getString("subjcode"),rs.getString("subjname"),rs.getInt("credits"),rs.getDouble("fees"));
               subjList.add(u);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Invalid Subjects");
        }
        return subjList;
    }
     public void showSubj(){
         //displayed subject table
        ArrayList<PGsubj> sList=subjList();
        DefaultTableModel model=(DefaultTableModel) tableSubject.getModel();
        //displayed subject table
        Object[] row=new Object[4];
        for(int i=0;i<sList.size();i++){
            row[0]=sList.get(i).getSubjcode();
            row[1]=sList.get(i).getSubjname();
            row[2]=sList.get(i).getCredits();
            row[3]=sList.get(i).getFees();
           model.addRow(row);
        }
    }
     public ArrayList<PGsubjectEnroll> subjEnList(){
        ArrayList<PGsubjectEnroll> subjEnList=new ArrayList<>();
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           String val4;
           val4=txtUgidEnroll.getText();
           String query1="SELECT * FROM pgsubjectenroll where pgid='"+val4+"'";
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(query1);
           PGsubjectEnroll u;
           while(rs.next()){
               //u=new UGstudents(rs.getString("ugid"),rs.getString("name"),rs.getString("dob"),rs.getString("gender"),rs.getString("address"),rs.getInt("tpno"),rs.getString("email"),rs.getString("alresult"),rs.getInt("rank"));
               u=new PGsubjectEnroll(rs.getString("faculty"),rs.getString("course"),rs.getString("month"),rs.getInt("year"),rs.getInt("semester"),rs.getString("pgid"),rs.getString("subjcode"),rs.getInt("credits"),rs.getDouble("fees"));
               subjEnList.add(u);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        return subjEnList;
    }
      public void showPGSubjEnroll(){
        ArrayList<PGsubjectEnroll> usList=subjEnList();
        DefaultTableModel model=(DefaultTableModel) tableUGsubj.getModel();
        Object[] row=new Object[4];
        for(int i=0;i<usList.size();i++){
            row[0]=usList.get(i).getPgid();
            row[1]=usList.get(i).getSubjcode();
            row[2]=usList.get(i).getCredits();
            row[3]=usList.get(i).getFees();
            model.addRow(row);
        }
    }
      
       public ArrayList<PgViewResult> viewResultList(){
        ArrayList<PgViewResult> viewList=new ArrayList<>();
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           String viewResultsUgid;
           viewResultsUgid=txtViewResultUgid.getText();
           String query1="SELECT * FROM pgsubjmarks where pgid='"+viewResultsUgid+"' ";
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(query1);
           PgViewResult u;
           
           while(rs.next()){
               //u=new UGstudents(rs.getString("ugid"),rs.getString("name"),rs.getString("dob"),rs.getString("gender"),rs.getString("address"),rs.getInt("tpno"),rs.getString("email"),rs.getString("alresult"),rs.getInt("rank"));
               u=new PgViewResult(rs.getString("subjcode"),rs.getString("grade"),rs.getInt("credits"));
               viewList.add(u);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null,  "Invalid subjects results");
        }
        return viewList;
    }
    public void viewPgResult(){
        ArrayList<PgViewResult> urList=viewResultList();
        DefaultTableModel model=(DefaultTableModel) tableUgResult.getModel();
        Object[] row=new Object[3];
        for(int i=0;i<urList.size();i++){
            //row[0]=uList.get(i).getCourse();
            row[0]=urList.get(i).getSubject();
            row[1]=urList.get(i).getFinalGrade();
            row[2]=urList.get(i).getCredits();
            
            model.addRow(row);
        }
    }
     
     
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        panelBase = new javax.swing.JPanel();
        panelFrontUG = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btnBackUGfrontpage1 = new javax.swing.JButton();
        btnRegisterStudents1 = new javax.swing.JButton();
        jLabel53 = new javax.swing.JLabel();
        btnEnrollUG1 = new javax.swing.JButton();
        btnResultsAnalysis1 = new javax.swing.JButton();
        jLabel55 = new javax.swing.JLabel();
        jLabel54 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelEdit = new javax.swing.JPanel();
        txtDob = new com.toedter.calendar.JDateChooser();
        txtAddress = new javax.swing.JTextField();
        txtTpno = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtQuaType = new javax.swing.JTextField();
        txtYearOfComp = new javax.swing.JTextField();
        lblUgid = new javax.swing.JLabel();
        jLabel39 = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        jLabel52 = new javax.swing.JLabel();
        jLabel56 = new javax.swing.JLabel();
        jLabel57 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        txtUgid = new javax.swing.JTextField();
        txtName = new javax.swing.JTextField();
        jLabel59 = new javax.swing.JLabel();
        radioM = new javax.swing.JRadioButton();
        radioF = new javax.swing.JRadioButton();
        txtSearch = new javax.swing.JTextField();
        lblPGSearch = new javax.swing.JLabel();
        jLabel60 = new javax.swing.JLabel();
        comboCourseReg = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        btnBack1 = new javax.swing.JButton();
        jLabel61 = new javax.swing.JLabel();
        jLabel62 = new javax.swing.JLabel();
        btnView1 = new javax.swing.JButton();
        btnNew = new javax.swing.JButton();
        btnSaveAdd = new javax.swing.JButton();
        btnUpdate = new javax.swing.JButton();
        btnDelete = new javax.swing.JButton();
        btnCancel1 = new javax.swing.JButton();
        jLabel63 = new javax.swing.JLabel();
        txtInstitute = new javax.swing.JTextField();
        panelEnroll = new javax.swing.JPanel();
        btnConfirm = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        txtUgidEnroll = new javax.swing.JTextField();
        txtEnrollGpa = new javax.swing.JTextField();
        lblEnrollGpa = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane8 = new javax.swing.JScrollPane();
        tableSubject = new javax.swing.JTable();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        comboCourse = new javax.swing.JComboBox<>();
        comboYear = new javax.swing.JComboBox<>();
        jLabel20 = new javax.swing.JLabel();
        comboSemester = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        comboMonth = new javax.swing.JComboBox<>();
        comboFaculty = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        goBackAdd = new javax.swing.JButton();
        btnEnrollAdd = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        txtSubjCodeEnroll = new javax.swing.JTextField();
        txtCalcCredit = new javax.swing.JTextField();
        txtCalcFees = new javax.swing.JTextField();
        lblCreditVerify = new javax.swing.JLabel();
        btnEnrollDeleteUG = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        btnEnrollConfirm = new javax.swing.JButton();
        txtC = new javax.swing.JTextField();
        txtCredits = new javax.swing.JTextField();
        txtFees = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableUGsubj = new javax.swing.JTable();
        jLabel33 = new javax.swing.JLabel();
        panelView = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        ugTable = new javax.swing.JTable();
        btnGoBackViewUG = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        comboViewCourse = new javax.swing.JComboBox<>();
        btnViewCourse = new javax.swing.JButton();
        btnViewClear = new javax.swing.JButton();
        panelMarks = new javax.swing.JPanel();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        panelViewResult = new javax.swing.JPanel();
        txtViewResultUgid = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableUgResult = new javax.swing.JTable();
        btnCalcGpa = new javax.swing.JButton();
        jButton10 = new javax.swing.JButton();
        btnClearResult = new javax.swing.JButton();
        lbl1 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel47 = new javax.swing.JLabel();
        txtGC = new javax.swing.JLabel();
        txtTotC = new javax.swing.JLabel();
        txtGpa = new javax.swing.JLabel();
        jButton4 = new javax.swing.JButton();
        panelAddResult = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        txta1 = new javax.swing.JTextField();
        txta2 = new javax.swing.JTextField();
        txta3 = new javax.swing.JTextField();
        txta4 = new javax.swing.JTextField();
        txta5 = new javax.swing.JTextField();
        txta6 = new javax.swing.JTextField();
        txta7 = new javax.swing.JTextField();
        txta8 = new javax.swing.JTextField();
        txta9 = new javax.swing.JTextField();
        txta10 = new javax.swing.JTextField();
        txtSubjCodeAddResult = new javax.swing.JTextField();
        txtUgidAddResult = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtExam = new javax.swing.JTextField();
        txtFinalGrade = new javax.swing.JTextField();
        btnCalcFinalGrade = new javax.swing.JButton();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        btnSaveAddResult = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        btnGoAddResult = new javax.swing.JButton();
        btnDeleteAddResult = new javax.swing.JButton();
        btnUpdateAddResult = new javax.swing.JButton();
        btnClearAddResult = new javax.swing.JButton();
        jLabel45 = new javax.swing.JLabel();
        txtAddCredits = new javax.swing.JTextField();
        jLabel64 = new javax.swing.JLabel();
        txtNoofAssi = new javax.swing.JLabel();
        txtAvgAssi = new javax.swing.JLabel();
        txtTotAssignments = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        panelBase.setLayout(new java.awt.CardLayout());

        panelFrontUG.setBackground(new java.awt.Color(0, 0, 51));
        panelFrontUG.setLayout(null);

        jPanel1.setBackground(new java.awt.Color(153, 255, 153));
        jPanel1.setLayout(null);

        btnBackUGfrontpage1.setBackground(new java.awt.Color(0, 0, 51));
        btnBackUGfrontpage1.setForeground(new java.awt.Color(0, 0, 51));
        btnBackUGfrontpage1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/home.png"))); // NOI18N
        btnBackUGfrontpage1.setContentAreaFilled(false);
        btnBackUGfrontpage1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackUGfrontpage1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnBackUGfrontpage1);
        btnBackUGfrontpage1.setBounds(10, 10, 90, 70);

        btnRegisterStudents1.setBackground(new java.awt.Color(255, 255, 255));
        btnRegisterStudents1.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        btnRegisterStudents1.setForeground(new java.awt.Color(0, 0, 51));
        btnRegisterStudents1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/register.png"))); // NOI18N
        btnRegisterStudents1.setBorder(null);
        btnRegisterStudents1.setContentAreaFilled(false);
        btnRegisterStudents1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegisterStudents1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegisterStudents1);
        btnRegisterStudents1.setBounds(140, 80, 90, 90);

        jLabel53.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel53.setText("Register Students");
        jPanel1.add(jLabel53);
        jLabel53.setBounds(110, 160, 190, 40);

        btnEnrollUG1.setBackground(new java.awt.Color(255, 255, 255));
        btnEnrollUG1.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        btnEnrollUG1.setForeground(new java.awt.Color(0, 0, 51));
        btnEnrollUG1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/enroll.png"))); // NOI18N
        btnEnrollUG1.setBorder(null);
        btnEnrollUG1.setContentAreaFilled(false);
        btnEnrollUG1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnrollUG1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnrollUG1);
        btnEnrollUG1.setBounds(140, 310, 100, 90);

        btnResultsAnalysis1.setBackground(new java.awt.Color(255, 255, 255));
        btnResultsAnalysis1.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        btnResultsAnalysis1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/resultsBlue.png"))); // NOI18N
        btnResultsAnalysis1.setBorder(null);
        btnResultsAnalysis1.setContentAreaFilled(false);
        btnResultsAnalysis1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResultsAnalysis1ActionPerformed(evt);
            }
        });
        jPanel1.add(btnResultsAnalysis1);
        btnResultsAnalysis1.setBounds(160, 550, 80, 80);

        jLabel55.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel55.setText("Results Analysis");
        jPanel1.add(jLabel55);
        jLabel55.setBounds(130, 650, 150, 30);

        jLabel54.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel54.setText("Enroll Subjects");
        jPanel1.add(jLabel54);
        jLabel54.setBounds(120, 410, 140, 30);

        panelFrontUG.add(jPanel1);
        jPanel1.setBounds(0, 0, 440, 1180);

        jLabel14.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 255, 153));
        jLabel14.setText("POSTGRADUATES");
        panelFrontUG.add(jLabel14);
        jLabel14.setBounds(700, 50, 340, 90);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/pgs.jpg"))); // NOI18N
        panelFrontUG.add(jLabel2);
        jLabel2.setBounds(500, 130, 760, 530);

        panelBase.add(panelFrontUG, "card2");

        panelEdit.setBackground(new java.awt.Color(0, 0, 51));
        panelEdit.setForeground(new java.awt.Color(153, 255, 153));
        panelEdit.setLayout(null);

        txtDob.setBackground(new java.awt.Color(204, 255, 204));
        txtDob.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtDob);
        txtDob.setBounds(830, 270, 290, 40);

        txtAddress.setBackground(new java.awt.Color(204, 255, 204));
        txtAddress.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtAddress.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtAddress);
        txtAddress.setBounds(830, 370, 290, 40);

        txtTpno.setBackground(new java.awt.Color(204, 255, 204));
        txtTpno.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtTpno.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtTpno);
        txtTpno.setBounds(830, 430, 290, 40);

        txtEmail.setBackground(new java.awt.Color(204, 255, 204));
        txtEmail.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtEmail.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtEmail);
        txtEmail.setBounds(830, 490, 290, 40);

        txtQuaType.setBackground(new java.awt.Color(204, 255, 204));
        txtQuaType.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtQuaType.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtQuaType);
        txtQuaType.setBounds(830, 550, 290, 40);

        txtYearOfComp.setBackground(new java.awt.Color(204, 255, 204));
        txtYearOfComp.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtYearOfComp.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtYearOfComp);
        txtYearOfComp.setBounds(830, 670, 290, 40);

        lblUgid.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblUgid.setForeground(new java.awt.Color(153, 255, 153));
        lblUgid.setText("PGID");
        panelEdit.add(lblUgid);
        lblUgid.setBounds(630, 160, 170, 23);

        jLabel39.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel39.setForeground(new java.awt.Color(153, 255, 153));
        jLabel39.setText("Name");
        panelEdit.add(jLabel39);
        jLabel39.setBounds(630, 220, 160, 23);

        jLabel40.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel40.setForeground(new java.awt.Color(153, 255, 153));
        jLabel40.setText("Date of Birth");
        panelEdit.add(jLabel40);
        jLabel40.setBounds(630, 280, 150, 23);

        jLabel51.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel51.setForeground(new java.awt.Color(153, 255, 153));
        jLabel51.setText("Address");
        panelEdit.add(jLabel51);
        jLabel51.setBounds(630, 380, 150, 23);

        jLabel52.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel52.setForeground(new java.awt.Color(153, 255, 153));
        jLabel52.setText("TP No.");
        panelEdit.add(jLabel52);
        jLabel52.setBounds(630, 440, 120, 23);

        jLabel56.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel56.setForeground(new java.awt.Color(153, 255, 153));
        jLabel56.setText("Email");
        panelEdit.add(jLabel56);
        jLabel56.setBounds(630, 500, 140, 23);

        jLabel57.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel57.setForeground(new java.awt.Color(153, 255, 153));
        jLabel57.setText("Qualification Type");
        panelEdit.add(jLabel57);
        jLabel57.setBounds(630, 560, 180, 23);

        jLabel58.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel58.setForeground(new java.awt.Color(153, 255, 153));
        jLabel58.setText("Year of Completion");
        panelEdit.add(jLabel58);
        jLabel58.setBounds(630, 680, 180, 23);

        txtUgid.setBackground(new java.awt.Color(204, 255, 204));
        txtUgid.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtUgid.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtUgid);
        txtUgid.setBounds(830, 150, 290, 40);

        txtName.setBackground(new java.awt.Color(204, 255, 204));
        txtName.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtName.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtName);
        txtName.setBounds(830, 210, 290, 40);

        jLabel59.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel59.setForeground(new java.awt.Color(153, 255, 153));
        jLabel59.setText("Gender");
        panelEdit.add(jLabel59);
        jLabel59.setBounds(630, 330, 150, 23);

        buttonGroup2.add(radioM);
        radioM.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        radioM.setForeground(new java.awt.Color(153, 255, 153));
        radioM.setText("Male");
        radioM.setContentAreaFilled(false);
        panelEdit.add(radioM);
        radioM.setBounds(830, 330, 110, 30);

        buttonGroup2.add(radioF);
        radioF.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        radioF.setForeground(new java.awt.Color(153, 255, 153));
        radioF.setText("Female");
        radioF.setContentAreaFilled(false);
        panelEdit.add(radioF);
        radioF.setBounds(990, 330, 110, 30);

        txtSearch.setBackground(new java.awt.Color(204, 255, 204));
        txtSearch.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtSearch.setForeground(new java.awt.Color(0, 0, 51));
        txtSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSearchActionPerformed(evt);
            }
        });
        txtSearch.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSearchKeyReleased(evt);
            }
        });
        panelEdit.add(txtSearch);
        txtSearch.setBounds(830, 30, 290, 40);

        lblPGSearch.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblPGSearch.setForeground(new java.awt.Color(153, 255, 153));
        lblPGSearch.setText("Search");
        panelEdit.add(lblPGSearch);
        lblPGSearch.setBounds(630, 30, 140, 23);

        jLabel60.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel60.setForeground(new java.awt.Color(153, 255, 153));
        jLabel60.setText("Course");
        panelEdit.add(jLabel60);
        jLabel60.setBounds(630, 100, 110, 23);

        comboCourseReg.setBackground(new java.awt.Color(204, 255, 204));
        comboCourseReg.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboCourseReg.setForeground(new java.awt.Color(0, 0, 51));
        comboCourseReg.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MCS", "MIS", "MBM", "MBA", "MME", "MEE" }));
        panelEdit.add(comboCourseReg);
        comboCourseReg.setBounds(830, 90, 290, 40);

        jPanel3.setBackground(new java.awt.Color(153, 255, 153));
        jPanel3.setLayout(null);

        btnBack1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBcakBlue.png"))); // NOI18N
        btnBack1.setContentAreaFilled(false);
        btnBack1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBack1ActionPerformed(evt);
            }
        });
        jPanel3.add(btnBack1);
        btnBack1.setBounds(0, 0, 80, 90);

        jLabel61.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel61.setForeground(new java.awt.Color(0, 0, 51));
        jLabel61.setText("Registration");
        jPanel3.add(jLabel61);
        jLabel61.setBounds(130, 150, 240, 45);

        jLabel62.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel62.setForeground(new java.awt.Color(0, 0, 51));
        jLabel62.setText("Postgraduates ");
        jPanel3.add(jLabel62);
        jLabel62.setBounds(110, 100, 320, 45);

        btnView1.setBackground(new java.awt.Color(255, 255, 255));
        btnView1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnView1.setForeground(new java.awt.Color(0, 0, 51));
        btnView1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/view.png"))); // NOI18N
        btnView1.setText("VIEW");
        btnView1.setContentAreaFilled(false);
        btnView1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnView1ActionPerformed(evt);
            }
        });
        jPanel3.add(btnView1);
        btnView1.setBounds(140, 240, 190, 60);

        btnNew.setBackground(new java.awt.Color(255, 255, 255));
        btnNew.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnNew.setForeground(new java.awt.Color(0, 0, 51));
        btnNew.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/new.png"))); // NOI18N
        btnNew.setText("NEW");
        btnNew.setContentAreaFilled(false);
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });
        jPanel3.add(btnNew);
        btnNew.setBounds(10, 350, 190, 60);

        btnSaveAdd.setBackground(new java.awt.Color(255, 255, 255));
        btnSaveAdd.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnSaveAdd.setForeground(new java.awt.Color(0, 0, 51));
        btnSaveAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/add.png"))); // NOI18N
        btnSaveAdd.setText("ADD");
        btnSaveAdd.setContentAreaFilled(false);
        btnSaveAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveAddActionPerformed(evt);
            }
        });
        jPanel3.add(btnSaveAdd);
        btnSaveAdd.setBounds(40, 440, 150, 60);

        btnUpdate.setBackground(new java.awt.Color(255, 255, 255));
        btnUpdate.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnUpdate.setForeground(new java.awt.Color(0, 0, 51));
        btnUpdate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/update.png"))); // NOI18N
        btnUpdate.setText("UPDATE");
        btnUpdate.setContentAreaFilled(false);
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        jPanel3.add(btnUpdate);
        btnUpdate.setBounds(210, 350, 190, 60);

        btnDelete.setBackground(new java.awt.Color(255, 255, 255));
        btnDelete.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnDelete.setForeground(new java.awt.Color(0, 0, 51));
        btnDelete.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/remove.png"))); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.setContentAreaFilled(false);
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });
        jPanel3.add(btnDelete);
        btnDelete.setBounds(210, 440, 190, 60);

        btnCancel1.setBackground(new java.awt.Color(255, 255, 255));
        btnCancel1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnCancel1.setForeground(new java.awt.Color(0, 0, 51));
        btnCancel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/cancel.png"))); // NOI18N
        btnCancel1.setText("CANCEL");
        btnCancel1.setContentAreaFilled(false);
        btnCancel1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCancel1ActionPerformed(evt);
            }
        });
        jPanel3.add(btnCancel1);
        btnCancel1.setBounds(150, 570, 190, 60);

        panelEdit.add(jPanel3);
        jPanel3.setBounds(0, 0, 470, 1040);

        jLabel63.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel63.setForeground(new java.awt.Color(153, 255, 153));
        jLabel63.setText("institute");
        panelEdit.add(jLabel63);
        jLabel63.setBounds(630, 620, 100, 23);

        txtInstitute.setBackground(new java.awt.Color(204, 255, 204));
        txtInstitute.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtInstitute.setForeground(new java.awt.Color(0, 0, 51));
        panelEdit.add(txtInstitute);
        txtInstitute.setBounds(830, 610, 290, 40);

        panelBase.add(panelEdit, "card2");

        panelEnroll.setBackground(new java.awt.Color(0, 0, 51));
        panelEnroll.setForeground(new java.awt.Color(0, 0, 51));
        panelEnroll.setLayout(null);

        btnConfirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/go.png"))); // NOI18N
        btnConfirm.setContentAreaFilled(false);
        btnConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConfirmActionPerformed(evt);
            }
        });
        panelEnroll.add(btnConfirm);
        btnConfirm.setBounds(1040, 150, 60, 60);

        jLabel5.setBackground(new java.awt.Color(0, 0, 51));
        jLabel5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(153, 255, 153));
        jLabel5.setText("PGID");
        panelEnroll.add(jLabel5);
        jLabel5.setBounds(780, 160, 60, 30);

        txtUgidEnroll.setBackground(new java.awt.Color(153, 255, 153));
        txtUgidEnroll.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtUgidEnroll.setForeground(new java.awt.Color(0, 0, 51));
        txtUgidEnroll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUgidEnrollActionPerformed(evt);
            }
        });
        txtUgidEnroll.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtUgidEnrollKeyReleased(evt);
            }
        });
        panelEnroll.add(txtUgidEnroll);
        txtUgidEnroll.setBounds(850, 150, 180, 50);

        txtEnrollGpa.setBackground(new java.awt.Color(0, 0, 51));
        txtEnrollGpa.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtEnrollGpa.setForeground(new java.awt.Color(0, 0, 51));
        txtEnrollGpa.setBorder(null);
        txtEnrollGpa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnrollGpaActionPerformed(evt);
            }
        });
        panelEnroll.add(txtEnrollGpa);
        txtEnrollGpa.setBounds(950, 780, 50, 40);

        lblEnrollGpa.setBackground(new java.awt.Color(0, 0, 51));
        lblEnrollGpa.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblEnrollGpa.setForeground(new java.awt.Color(0, 0, 51));
        lblEnrollGpa.setText("Current GPA");
        panelEnroll.add(lblEnrollGpa);
        lblEnrollGpa.setBounds(950, 880, 40, 23);

        jPanel4.setBackground(new java.awt.Color(153, 255, 153));
        jPanel4.setLayout(null);

        jScrollPane8.setForeground(new java.awt.Color(204, 0, 0));

        tableSubject.setBackground(new java.awt.Color(0, 0, 51));
        tableSubject.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        tableSubject.setForeground(new java.awt.Color(153, 255, 153));
        tableSubject.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject Code", "Subject Name", "No.of Credits", "Fees"
            }
        ));
        tableSubject.setGridColor(new java.awt.Color(153, 255, 153));
        tableSubject.setRowHeight(30);
        tableSubject.setSelectionBackground(new java.awt.Color(102, 153, 255));
        jScrollPane8.setViewportView(tableSubject);

        jPanel4.add(jScrollPane8);
        jScrollPane8.setBounds(70, 360, 520, 290);

        jLabel19.setBackground(new java.awt.Color(0, 0, 51));
        jLabel19.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 51));
        jLabel19.setText("Course");
        jPanel4.add(jLabel19);
        jLabel19.setBounds(80, 130, 110, 30);

        jLabel21.setBackground(new java.awt.Color(0, 0, 51));
        jLabel21.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 51));
        jLabel21.setText("Semester");
        jPanel4.add(jLabel21);
        jLabel21.setBounds(80, 220, 120, 23);

        comboCourse.setBackground(new java.awt.Color(153, 255, 153));
        comboCourse.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboCourse.setForeground(new java.awt.Color(0, 0, 51));
        comboCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MCS", "MIS", "MBM", "MBA", "MME", "MEE" }));
        comboCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboCourseMouseClicked(evt);
            }
        });
        jPanel4.add(comboCourse);
        comboCourse.setBounds(240, 130, 280, 29);

        comboYear.setBackground(new java.awt.Color(153, 255, 153));
        comboYear.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboYear.setForeground(new java.awt.Color(0, 0, 51));
        comboYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2" }));
        jPanel4.add(comboYear);
        comboYear.setBounds(240, 170, 280, 30);

        jLabel20.setBackground(new java.awt.Color(0, 0, 51));
        jLabel20.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 51));
        jLabel20.setText("Year");
        jPanel4.add(jLabel20);
        jLabel20.setBounds(80, 170, 120, 30);

        comboSemester.setBackground(new java.awt.Color(153, 255, 153));
        comboSemester.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboSemester.setForeground(new java.awt.Color(0, 0, 51));
        comboSemester.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2" }));
        jPanel4.add(comboSemester);
        comboSemester.setBounds(240, 210, 280, 30);

        jLabel1.setBackground(new java.awt.Color(0, 0, 51));
        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 51));
        jLabel1.setText("Intake");
        jPanel4.add(jLabel1);
        jLabel1.setBounds(80, 260, 120, 30);

        comboMonth.setBackground(new java.awt.Color(153, 255, 153));
        comboMonth.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboMonth.setForeground(new java.awt.Color(0, 0, 51));
        comboMonth.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "February", "July" }));
        jPanel4.add(comboMonth);
        comboMonth.setBounds(240, 250, 280, 30);

        comboFaculty.setBackground(new java.awt.Color(153, 255, 153));
        comboFaculty.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboFaculty.setForeground(new java.awt.Color(0, 0, 51));
        comboFaculty.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "School Of Computing", "School Of Business", "School Of Engineering" }));
        jPanel4.add(comboFaculty);
        comboFaculty.setBounds(240, 90, 280, 30);

        jLabel17.setBackground(new java.awt.Color(0, 0, 51));
        jLabel17.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 51));
        jLabel17.setText("Faculty");
        jPanel4.add(jLabel17);
        jLabel17.setBounds(80, 80, 150, 50);

        goBackAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBcakBlue.png"))); // NOI18N
        goBackAdd.setContentAreaFilled(false);
        goBackAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                goBackAddActionPerformed(evt);
            }
        });
        jPanel4.add(goBackAdd);
        goBackAdd.setBounds(10, 10, 60, 60);

        btnEnrollAdd.setBackground(new java.awt.Color(153, 255, 153));
        btnEnrollAdd.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnEnrollAdd.setForeground(new java.awt.Color(153, 255, 153));
        btnEnrollAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/plusBlue.png"))); // NOI18N
        btnEnrollAdd.setContentAreaFilled(false);
        btnEnrollAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnrollAddActionPerformed(evt);
            }
        });
        jPanel4.add(btnEnrollAdd);
        btnEnrollAdd.setBounds(610, 460, 60, 60);

        jLabel18.setBackground(new java.awt.Color(153, 255, 153));
        jLabel18.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 51));
        jLabel18.setText("Postgraduates");
        jPanel4.add(jLabel18);
        jLabel18.setBounds(420, 0, 270, 60);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/myGo.png"))); // NOI18N
        jButton1.setContentAreaFilled(false);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton1);
        jButton1.setBounds(340, 290, 70, 50);

        panelEnroll.add(jPanel4);
        jPanel4.setBounds(0, 0, 680, 1020);

        jLabel6.setBackground(new java.awt.Color(153, 255, 153));
        jLabel6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 51));
        jLabel6.setText("Subject Code");
        panelEnroll.add(jLabel6);
        jLabel6.setBounds(950, 920, 40, 23);

        txtSubjCodeEnroll.setBackground(new java.awt.Color(0, 0, 51));
        txtSubjCodeEnroll.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtSubjCodeEnroll.setForeground(new java.awt.Color(0, 0, 51));
        txtSubjCodeEnroll.setBorder(null);
        txtSubjCodeEnroll.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSubjCodeEnrollKeyReleased(evt);
            }
        });
        panelEnroll.add(txtSubjCodeEnroll);
        txtSubjCodeEnroll.setBounds(1010, 780, 50, 40);

        txtCalcCredit.setBackground(new java.awt.Color(153, 255, 153));
        txtCalcCredit.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtCalcCredit.setForeground(new java.awt.Color(0, 0, 51));
        panelEnroll.add(txtCalcCredit);
        txtCalcCredit.setBounds(1030, 650, 110, 40);

        txtCalcFees.setBackground(new java.awt.Color(153, 255, 153));
        txtCalcFees.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtCalcFees.setForeground(new java.awt.Color(0, 0, 51));
        panelEnroll.add(txtCalcFees);
        txtCalcFees.setBounds(1150, 650, 110, 40);

        lblCreditVerify.setBackground(new java.awt.Color(153, 255, 153));
        lblCreditVerify.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblCreditVerify.setForeground(new java.awt.Color(255, 0, 0));
        panelEnroll.add(lblCreditVerify);
        lblCreditVerify.setBounds(820, 260, 310, 30);

        btnEnrollDeleteUG.setBackground(new java.awt.Color(153, 255, 153));
        btnEnrollDeleteUG.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnEnrollDeleteUG.setForeground(new java.awt.Color(153, 255, 153));
        btnEnrollDeleteUG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPackage/deleteLightGreen.png"))); // NOI18N
        btnEnrollDeleteUG.setContentAreaFilled(false);
        btnEnrollDeleteUG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnrollDeleteUGActionPerformed(evt);
            }
        });
        panelEnroll.add(btnEnrollDeleteUG);
        btnEnrollDeleteUG.setBounds(680, 470, 90, 50);

        jButton5.setBackground(new java.awt.Color(153, 255, 153));
        jButton5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton5.setForeground(new java.awt.Color(153, 255, 153));
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/clearBigGreen.png"))); // NOI18N
        jButton5.setContentAreaFilled(false);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        panelEnroll.add(jButton5);
        jButton5.setBounds(1150, 160, 100, 50);

        btnEnrollConfirm.setBackground(new java.awt.Color(255, 255, 255));
        btnEnrollConfirm.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnEnrollConfirm.setForeground(new java.awt.Color(153, 255, 153));
        btnEnrollConfirm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/correctGreen.png"))); // NOI18N
        btnEnrollConfirm.setText("Confirm");
        btnEnrollConfirm.setContentAreaFilled(false);
        btnEnrollConfirm.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnrollConfirmActionPerformed(evt);
            }
        });
        panelEnroll.add(btnEnrollConfirm);
        btnEnrollConfirm.setBounds(680, 650, 170, 60);

        txtC.setBackground(new java.awt.Color(0, 0, 51));
        txtC.setBorder(null);
        panelEnroll.add(txtC);
        txtC.setBounds(1010, 890, 30, 14);

        txtCredits.setBackground(new java.awt.Color(0, 0, 51));
        txtCredits.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtCredits.setForeground(new java.awt.Color(0, 0, 51));
        txtCredits.setBorder(null);
        panelEnroll.add(txtCredits);
        txtCredits.setBounds(1010, 920, 30, 20);

        txtFees.setBackground(new java.awt.Color(0, 0, 51));
        txtFees.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtFees.setForeground(new java.awt.Color(0, 0, 51));
        txtFees.setBorder(null);
        txtFees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFeesActionPerformed(evt);
            }
        });
        panelEnroll.add(txtFees);
        txtFees.setBounds(1010, 950, 30, 20);

        tableUGsubj.setBackground(new java.awt.Color(0, 0, 51));
        tableUGsubj.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        tableUGsubj.setForeground(new java.awt.Color(153, 255, 153));
        tableUGsubj.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PGID", "Subject Code", "Credits", "Fees"
            }
        ));
        tableUGsubj.setRowHeight(30);
        tableUGsubj.setSelectionBackground(new java.awt.Color(102, 153, 255));
        tableUGsubj.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableUGsubjMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tableUGsubj);

        panelEnroll.add(jScrollPane3);
        jScrollPane3.setBounds(770, 360, 490, 280);

        jLabel33.setBackground(new java.awt.Color(153, 255, 153));
        jLabel33.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel33.setForeground(new java.awt.Color(153, 255, 153));
        jLabel33.setText(" Subject Enrollment");
        panelEnroll.add(jLabel33);
        jLabel33.setBounds(680, 0, 350, 60);

        panelBase.add(panelEnroll, "card9");

        panelView.setBackground(new java.awt.Color(0, 0, 51));
        panelView.setLayout(null);

        jLabel22.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(153, 255, 153));
        jLabel22.setText("View Postgraduates");
        panelView.add(jLabel22);
        jLabel22.setBounds(480, 10, 460, 60);

        ugTable.setBackground(new java.awt.Color(153, 255, 153));
        ugTable.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        ugTable.setForeground(new java.awt.Color(0, 0, 51));
        ugTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "PGID", "Name", "DOB", "Gender", "Address", "TP no", "Email", "Qualification Type", "Institute", "Year of Completion"
            }
        ));
        ugTable.setGridColor(new java.awt.Color(153, 255, 153));
        ugTable.setInheritsPopupMenu(true);
        ugTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ugTableMouseClicked(evt);
            }
        });
        jScrollPane9.setViewportView(ugTable);

        panelView.add(jScrollPane9);
        jScrollPane9.setBounds(90, 180, 1120, 410);

        btnGoBackViewUG.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBack.png"))); // NOI18N
        btnGoBackViewUG.setContentAreaFilled(false);
        btnGoBackViewUG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGoBackViewUGActionPerformed(evt);
            }
        });
        panelView.add(btnGoBackViewUG);
        btnGoBackViewUG.setBounds(10, 15, 80, 73);

        jLabel9.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 255, 153));
        jLabel9.setText("Course");
        panelView.add(jLabel9);
        jLabel9.setBounds(450, 100, 80, 40);

        comboViewCourse.setBackground(new java.awt.Color(153, 255, 153));
        comboViewCourse.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboViewCourse.setForeground(new java.awt.Color(0, 0, 51));
        comboViewCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "MCS", "MIS", "MBM", "MBA", "MME", "MEE" }));
        panelView.add(comboViewCourse);
        comboViewCourse.setBounds(560, 100, 230, 40);

        btnViewCourse.setBackground(new java.awt.Color(153, 255, 153));
        btnViewCourse.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnViewCourse.setForeground(new java.awt.Color(0, 0, 51));
        btnViewCourse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/greenGo.png"))); // NOI18N
        btnViewCourse.setContentAreaFilled(false);
        btnViewCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewCourseActionPerformed(evt);
            }
        });
        panelView.add(btnViewCourse);
        btnViewCourse.setBounds(840, 80, 70, 80);

        btnViewClear.setBackground(new java.awt.Color(153, 255, 153));
        btnViewClear.setFont(new java.awt.Font("Century Gothic", 0, 20)); // NOI18N
        btnViewClear.setForeground(new java.awt.Color(153, 255, 153));
        btnViewClear.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/clearAll.png"))); // NOI18N
        btnViewClear.setContentAreaFilled(false);
        btnViewClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnViewClearActionPerformed(evt);
            }
        });
        panelView.add(btnViewClear);
        btnViewClear.setBounds(1140, 90, 83, 60);

        panelBase.add(panelView, "card2");

        panelMarks.setBackground(new java.awt.Color(0, 0, 51));
        panelMarks.setLayout(null);

        jButton2.setBackground(new java.awt.Color(255, 255, 255));
        jButton2.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jButton2.setForeground(new java.awt.Color(153, 255, 153));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/addResult.png"))); // NOI18N
        jButton2.setText("Add Result");
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        panelMarks.add(jButton2);
        jButton2.setBounds(370, 150, 300, 100);

        jButton3.setBackground(new java.awt.Color(255, 255, 255));
        jButton3.setFont(new java.awt.Font("Century Gothic", 0, 24)); // NOI18N
        jButton3.setForeground(new java.awt.Color(153, 255, 153));
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/viewResult.png"))); // NOI18N
        jButton3.setText("View Result");
        jButton3.setContentAreaFilled(false);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        panelMarks.add(jButton3);
        jButton3.setBounds(710, 150, 280, 100);

        jLabel10.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(153, 255, 153));
        jLabel10.setText("Postgraduates Results Management Unit");
        panelMarks.add(jLabel10);
        jLabel10.setBounds(290, 30, 790, 80);

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBack.png"))); // NOI18N
        jButton9.setContentAreaFilled(false);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        panelMarks.add(jButton9);
        jButton9.setBounds(0, 10, 100, 80);

        jPanel2.setBackground(new java.awt.Color(153, 255, 153));
        jPanel2.setLayout(null);
        panelMarks.add(jPanel2);
        jPanel2.setBounds(0, 300, 1610, 780);

        panelBase.add(panelMarks, "card2");

        panelViewResult.setBackground(new java.awt.Color(0, 0, 51));
        panelViewResult.setLayout(null);

        txtViewResultUgid.setBackground(new java.awt.Color(204, 255, 204));
        txtViewResultUgid.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtViewResultUgid.setForeground(new java.awt.Color(0, 0, 51));
        txtViewResultUgid.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtViewResultUgidKeyReleased(evt);
            }
        });
        panelViewResult.add(txtViewResultUgid);
        txtViewResultUgid.setBounds(230, 70, 200, 50);

        jLabel11.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(153, 255, 153));
        jLabel11.setText("PGID");
        panelViewResult.add(jLabel11);
        jLabel11.setBounds(160, 80, 80, 40);

        tableUgResult.setBackground(new java.awt.Color(153, 255, 153));
        tableUgResult.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        tableUgResult.setForeground(new java.awt.Color(0, 0, 51));
        tableUgResult.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Subject", "Grade", "Credits"
            }
        ));
        tableUgResult.setRowHeight(30);
        jScrollPane1.setViewportView(tableUgResult);

        panelViewResult.add(jScrollPane1);
        jScrollPane1.setBounds(360, 260, 630, 300);

        btnCalcGpa.setBackground(new java.awt.Color(255, 255, 255));
        btnCalcGpa.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnCalcGpa.setForeground(new java.awt.Color(153, 255, 153));
        btnCalcGpa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/calc.png"))); // NOI18N
        btnCalcGpa.setText("GPA");
        btnCalcGpa.setContentAreaFilled(false);
        btnCalcGpa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcGpaActionPerformed(evt);
            }
        });
        panelViewResult.add(btnCalcGpa);
        btnCalcGpa.setBounds(200, 150, 150, 60);

        jButton10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBack.png"))); // NOI18N
        jButton10.setContentAreaFilled(false);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        panelViewResult.add(jButton10);
        jButton10.setBounds(10, 10, 80, 70);

        btnClearResult.setBackground(new java.awt.Color(255, 255, 255));
        btnClearResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnClearResult.setForeground(new java.awt.Color(153, 255, 153));
        btnClearResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/clearBigGreen.png"))); // NOI18N
        btnClearResult.setContentAreaFilled(false);
        btnClearResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearResultActionPerformed(evt);
            }
        });
        panelViewResult.add(btnClearResult);
        btnClearResult.setBounds(450, 70, 80, 59);
        panelViewResult.add(lbl1);
        lbl1.setBounds(730, 190, 0, 0);

        jLabel46.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel46.setForeground(new java.awt.Color(153, 255, 153));
        jLabel46.setText("Grade*Credits");
        panelViewResult.add(jLabel46);
        jLabel46.setBounds(670, 130, 150, 30);

        jLabel47.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel47.setForeground(new java.awt.Color(153, 255, 153));
        jLabel47.setText("Total Credits");
        panelViewResult.add(jLabel47);
        jLabel47.setBounds(670, 80, 170, 30);

        txtGC.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtGC.setForeground(new java.awt.Color(204, 255, 204));
        panelViewResult.add(txtGC);
        txtGC.setBounds(840, 120, 120, 40);

        txtTotC.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtTotC.setForeground(new java.awt.Color(204, 255, 204));
        panelViewResult.add(txtTotC);
        txtTotC.setBounds(840, 70, 120, 40);

        txtGpa.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtGpa.setForeground(new java.awt.Color(153, 255, 153));
        panelViewResult.add(txtGpa);
        txtGpa.setBounds(360, 160, 110, 50);

        jButton4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton4.setForeground(new java.awt.Color(153, 255, 153));
        jButton4.setText("Send Email");
        jButton4.setContentAreaFilled(false);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        panelViewResult.add(jButton4);
        jButton4.setBounds(610, 630, 130, 40);

        panelBase.add(panelViewResult, "card2");

        panelAddResult.setBackground(new java.awt.Color(0, 0, 51));
        panelAddResult.setForeground(new java.awt.Color(204, 255, 204));
        panelAddResult.setLayout(null);

        jLabel13.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 255, 153));
        jLabel13.setText("Welcome to Add Result Page");
        panelAddResult.add(jLabel13);
        jLabel13.setBounds(380, 10, 620, 60);

        jLabel16.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(153, 255, 153));
        jLabel16.setText("PGID");
        panelAddResult.add(jLabel16);
        jLabel16.setBounds(180, 100, 50, 23);

        jLabel25.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel25.setForeground(new java.awt.Color(153, 255, 153));
        jLabel25.setText("Subject");
        panelAddResult.add(jLabel25);
        jLabel25.setBounds(180, 150, 100, 30);

        jLabel27.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel27.setForeground(new java.awt.Color(153, 255, 153));
        jLabel27.setText("Assignment 4 :");
        panelAddResult.add(jLabel27);
        jLabel27.setBounds(810, 330, 140, 23);

        jLabel28.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(153, 255, 153));
        jLabel28.setText("Assignment 1 :");
        panelAddResult.add(jLabel28);
        jLabel28.setBounds(810, 170, 150, 30);

        jLabel29.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel29.setForeground(new java.awt.Color(153, 255, 153));
        jLabel29.setText("Assignment 2 :");
        panelAddResult.add(jLabel29);
        jLabel29.setBounds(810, 230, 140, 23);

        jLabel30.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel30.setForeground(new java.awt.Color(153, 255, 153));
        jLabel30.setText("Assignment 5 :");
        panelAddResult.add(jLabel30);
        jLabel30.setBounds(810, 380, 140, 23);

        jLabel31.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(153, 255, 153));
        jLabel31.setText("Assignment 6 :");
        panelAddResult.add(jLabel31);
        jLabel31.setBounds(810, 430, 140, 23);

        jLabel32.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(153, 255, 153));
        jLabel32.setText("Assignment 7 :");
        panelAddResult.add(jLabel32);
        jLabel32.setBounds(810, 480, 150, 23);

        jLabel37.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel37.setForeground(new java.awt.Color(153, 255, 153));
        jLabel37.setText("Assignment 9 :");
        panelAddResult.add(jLabel37);
        jLabel37.setBounds(810, 580, 160, 23);

        jLabel41.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel41.setForeground(new java.awt.Color(153, 255, 153));
        jLabel41.setText("Assignment 3 :");
        panelAddResult.add(jLabel41);
        jLabel41.setBounds(810, 280, 150, 23);

        jLabel43.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel43.setForeground(new java.awt.Color(153, 255, 153));
        jLabel43.setText("Assignment 10 :");
        panelAddResult.add(jLabel43);
        jLabel43.setBounds(810, 630, 150, 23);

        jLabel44.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel44.setForeground(new java.awt.Color(153, 255, 153));
        jLabel44.setText("Assignment 8 :");
        panelAddResult.add(jLabel44);
        jLabel44.setBounds(810, 530, 140, 23);

        txta1.setBackground(new java.awt.Color(204, 255, 204));
        txta1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta1.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta1);
        txta1.setBounds(1000, 170, 130, 40);

        txta2.setBackground(new java.awt.Color(204, 255, 204));
        txta2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta2.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta2);
        txta2.setBounds(1000, 220, 130, 40);

        txta3.setBackground(new java.awt.Color(204, 255, 204));
        txta3.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta3.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta3);
        txta3.setBounds(1000, 270, 130, 40);

        txta4.setBackground(new java.awt.Color(204, 255, 204));
        txta4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta4.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta4);
        txta4.setBounds(1000, 320, 130, 40);

        txta5.setBackground(new java.awt.Color(204, 255, 204));
        txta5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta5.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta5);
        txta5.setBounds(1000, 370, 130, 40);

        txta6.setBackground(new java.awt.Color(204, 255, 204));
        txta6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta6.setForeground(new java.awt.Color(0, 0, 51));
        txta6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txta6ActionPerformed(evt);
            }
        });
        panelAddResult.add(txta6);
        txta6.setBounds(1000, 420, 130, 40);

        txta7.setBackground(new java.awt.Color(204, 255, 204));
        txta7.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta7.setForeground(new java.awt.Color(0, 0, 51));
        txta7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txta7ActionPerformed(evt);
            }
        });
        panelAddResult.add(txta7);
        txta7.setBounds(1000, 470, 130, 40);

        txta8.setBackground(new java.awt.Color(204, 255, 204));
        txta8.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta8.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta8);
        txta8.setBounds(1000, 520, 130, 40);

        txta9.setBackground(new java.awt.Color(204, 255, 204));
        txta9.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta9.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta9);
        txta9.setBounds(1000, 570, 130, 40);

        txta10.setBackground(new java.awt.Color(204, 255, 204));
        txta10.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txta10.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txta10);
        txta10.setBounds(1000, 620, 130, 40);

        txtSubjCodeAddResult.setBackground(new java.awt.Color(204, 255, 204));
        txtSubjCodeAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtSubjCodeAddResult.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txtSubjCodeAddResult);
        txtSubjCodeAddResult.setBounds(340, 150, 180, 40);

        txtUgidAddResult.setBackground(new java.awt.Color(204, 255, 204));
        txtUgidAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtUgidAddResult.setForeground(new java.awt.Color(0, 0, 51));
        txtUgidAddResult.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtUgidAddResultKeyReleased(evt);
            }
        });
        panelAddResult.add(txtUgidAddResult);
        txtUgidAddResult.setBounds(340, 100, 180, 40);

        jLabel12.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(153, 255, 153));
        jLabel12.setText("Exam");
        panelAddResult.add(jLabel12);
        jLabel12.setBounds(180, 250, 100, 40);

        txtExam.setBackground(new java.awt.Color(204, 255, 204));
        txtExam.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtExam.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txtExam);
        txtExam.setBounds(340, 250, 100, 50);

        txtFinalGrade.setBackground(new java.awt.Color(204, 255, 204));
        txtFinalGrade.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtFinalGrade.setForeground(new java.awt.Color(0, 0, 51));
        panelAddResult.add(txtFinalGrade);
        txtFinalGrade.setBounds(340, 490, 100, 50);

        btnCalcFinalGrade.setBackground(new java.awt.Color(255, 255, 255));
        btnCalcFinalGrade.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnCalcFinalGrade.setForeground(new java.awt.Color(153, 255, 153));
        btnCalcFinalGrade.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/find.png"))); // NOI18N
        btnCalcFinalGrade.setText("Grade");
        btnCalcFinalGrade.setContentAreaFilled(false);
        btnCalcFinalGrade.setHorizontalTextPosition(javax.swing.SwingConstants.LEADING);
        btnCalcFinalGrade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcFinalGradeActionPerformed(evt);
            }
        });
        panelAddResult.add(btnCalcFinalGrade);
        btnCalcFinalGrade.setBounds(150, 490, 170, 60);

        jLabel23.setFont(new java.awt.Font("Century Gothic", 0, 22)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(153, 255, 153));
        jLabel23.setText("Enter the Relavant Assignemnt Marks below : ");
        panelAddResult.add(jLabel23);
        jLabel23.setBounds(720, 100, 510, 40);

        jLabel24.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(153, 255, 153));
        jLabel24.setText("Count");
        panelAddResult.add(jLabel24);
        jLabel24.setBounds(180, 370, 70, 40);

        jLabel26.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(153, 255, 153));
        jLabel26.setText("Average");
        panelAddResult.add(jLabel26);
        jLabel26.setBounds(180, 430, 100, 40);

        btnSaveAddResult.setBackground(new java.awt.Color(102, 255, 0));
        btnSaveAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnSaveAddResult.setForeground(new java.awt.Color(153, 255, 153));
        btnSaveAddResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/saveResult.png"))); // NOI18N
        btnSaveAddResult.setContentAreaFilled(false);
        btnSaveAddResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveAddResultActionPerformed(evt);
            }
        });
        panelAddResult.add(btnSaveAddResult);
        btnSaveAddResult.setBounds(60, 640, 150, 50);

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goBack.png"))); // NOI18N
        jButton8.setContentAreaFilled(false);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        panelAddResult.add(jButton8);
        jButton8.setBounds(10, 10, 90, 70);

        btnGoAddResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/goGreen.png"))); // NOI18N
        btnGoAddResult.setContentAreaFilled(false);
        btnGoAddResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGoAddResultActionPerformed(evt);
            }
        });
        panelAddResult.add(btnGoAddResult);
        btnGoAddResult.setBounds(550, 110, 70, 60);

        btnDeleteAddResult.setBackground(new java.awt.Color(0, 255, 0));
        btnDeleteAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnDeleteAddResult.setForeground(new java.awt.Color(153, 255, 153));
        btnDeleteAddResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/deleteResult.png"))); // NOI18N
        btnDeleteAddResult.setContentAreaFilled(false);
        btnDeleteAddResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteAddResultActionPerformed(evt);
            }
        });
        panelAddResult.add(btnDeleteAddResult);
        btnDeleteAddResult.setBounds(400, 640, 150, 50);

        btnUpdateAddResult.setBackground(new java.awt.Color(0, 255, 0));
        btnUpdateAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnUpdateAddResult.setForeground(new java.awt.Color(153, 255, 153));
        btnUpdateAddResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/updateResult.png"))); // NOI18N
        btnUpdateAddResult.setContentAreaFilled(false);
        btnUpdateAddResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateAddResultActionPerformed(evt);
            }
        });
        panelAddResult.add(btnUpdateAddResult);
        btnUpdateAddResult.setBounds(230, 640, 160, 50);

        btnClearAddResult.setBackground(new java.awt.Color(0, 255, 0));
        btnClearAddResult.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnClearAddResult.setForeground(new java.awt.Color(153, 255, 153));
        btnClearAddResult.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/clearBigGreen.png"))); // NOI18N
        btnClearAddResult.setContentAreaFilled(false);
        btnClearAddResult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAddResultActionPerformed(evt);
            }
        });
        panelAddResult.add(btnClearAddResult);
        btnClearAddResult.setBounds(540, 640, 100, 60);

        jLabel45.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel45.setForeground(new java.awt.Color(0, 0, 51));
        jLabel45.setText("Credits");
        panelAddResult.add(jLabel45);
        jLabel45.setBounds(660, 300, 40, 40);

        txtAddCredits.setBackground(new java.awt.Color(0, 0, 51));
        txtAddCredits.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtAddCredits.setForeground(new java.awt.Color(0, 0, 51));
        txtAddCredits.setBorder(null);
        panelAddResult.add(txtAddCredits);
        txtAddCredits.setBounds(650, 350, 50, 30);

        jLabel64.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel64.setForeground(new java.awt.Color(153, 255, 153));
        jLabel64.setText("Total");
        panelAddResult.add(jLabel64);
        jLabel64.setBounds(180, 320, 80, 30);

        txtNoofAssi.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtNoofAssi.setForeground(new java.awt.Color(204, 255, 204));
        panelAddResult.add(txtNoofAssi);
        txtNoofAssi.setBounds(340, 370, 80, 40);

        txtAvgAssi.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtAvgAssi.setForeground(new java.awt.Color(204, 255, 204));
        panelAddResult.add(txtAvgAssi);
        txtAvgAssi.setBounds(340, 420, 80, 40);

        txtTotAssignments.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtTotAssignments.setForeground(new java.awt.Color(204, 255, 204));
        panelAddResult.add(txtTotAssignments);
        txtTotAssignments.setBounds(340, 320, 80, 40);

        panelBase.add(panelAddResult, "card2");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelBase, javax.swing.GroupLayout.DEFAULT_SIZE, 1522, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(0, 0, 0)
                .addComponent(panelBase, javax.swing.GroupLayout.DEFAULT_SIZE, 1081, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegisterStudents1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegisterStudents1ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelEdit);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_btnRegisterStudents1ActionPerformed

    private void btnEnrollUG1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnrollUG1ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelEnroll);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_btnEnrollUG1ActionPerformed

    private void btnResultsAnalysis1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResultsAnalysis1ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelMarks);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_btnResultsAnalysis1ActionPerformed

    private void btnBackUGfrontpage1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackUGfrontpage1ActionPerformed
        MainMenu m=new MainMenu();
    }//GEN-LAST:event_btnBackUGfrontpage1ActionPerformed

    private void txtSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSearchActionPerformed

    private void txtSearchKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSearchKeyReleased
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valUgid=txtSearch.getText();
            String sql="SELECT * FROM pgstudents WHERE pgid='"+valUgid+"' ";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();

            if(rs.next()){
                String crs=rs.getString("course");
             switch(crs){
            case "MCS":
                comboCourseReg.setSelectedIndex(0);
                break;
            case "MIS":
                comboCourseReg.setSelectedIndex(1);
                break;
            case "MBM":
                comboCourseReg.setSelectedIndex(2);
                break;
            case "MBA":
                comboCourseReg.setSelectedIndex(3);
                break;
            case "MME":
                comboCourseReg.setSelectedIndex(4);
                break;
            case "MEE":
                comboCourseReg.setSelectedIndex(5);
                break;
             }
                String setUgid=rs.getString("pgid");
                txtUgid.setText(setUgid);
                String setName=rs.getString("name");
                txtName.setText(setName);
                Date dateob=rs.getDate("dob");
                txtDob.setDate(dateob);

                String sex=rs.getString("gender");
                if(sex.equals("Male")){
                    radioM.setSelected(true);
                }
                else{
                    radioF.setSelected(true);
                }
                String setAddress=rs.getString("address");
                txtAddress.setText(setAddress);
                String setTpno=rs.getString("tpno");
                txtTpno.setText(setTpno);
                String setEmail=rs.getString("email");
                txtEmail.setText(setEmail);
                String setQuaType=rs.getString("quatype");
                txtQuaType.setText(setQuaType);
                String setIns=rs.getString("institute");
                txtInstitute.setText(setIns);
                String setYear=rs.getString("yearcomplete");
                txtYearOfComp.setText(setYear);

            }
            else{
                txtUgid.setText("");
                txtName.setText("");
                txtDob.setDate(null);
                radioM.setSelected(false);
                radioF.setSelected(false);
                txtAddress.setText("");
                txtTpno.setText("");
                txtEmail.setText("");
                txtInstitute.setText("");
                txtQuaType.setText("");
                txtYearOfComp.setText("");
                comboCourseReg.setSelectedIndex(0);

            }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Student does not exist in the system");
        }
    }//GEN-LAST:event_txtSearchKeyReleased

    private void btnBack1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBack1ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelFrontUG);
        panelBase.repaint();
        panelBase.revalidate();

    }//GEN-LAST:event_btnBack1ActionPerformed

    private void btnView1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnView1ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelView);
        panelBase.repaint();
        panelBase.revalidate();

    }//GEN-LAST:event_btnView1ActionPerformed

    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
        txtUgid.setEditable(true);
        txtUgid.setText("");
        txtName.setText("");
        txtDob.setDate(null);
        comboCourseReg.setSelectedIndex(0);
        buttonGroup2.clearSelection();
        txtAddress.setText("");
        txtTpno.setText("");
        txtEmail.setText("");
        txtQuaType.setText("");
        txtInstitute.setText("");
        txtYearOfComp.setText("");
        btnDelete.setVisible(false);
        btnUpdate.setVisible(false);
        txtSearch.setVisible(false);
        jLabel5.setVisible(false);
        lblPGSearch.setVisible(false);

    }//GEN-LAST:event_btnNewActionPerformed

    private void btnSaveAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveAddActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String query="insert into pgstudents(course,pgid,name,dob,gender,address,tpno,email,quatype,institute,yearcomplete) values(?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            String courseRegAdd;
            courseRegAdd=comboCourseReg.getSelectedItem().toString();
            pst.setString(1, courseRegAdd);
            pst.setString(2, txtUgid.getText());
            pst.setString(3, txtName.getText());
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
            String date=sdf.format(txtDob.getDate());
            pst.setString(4, date);

            if(radioM.isSelected()){
                gender="Male";
            }
            if(radioF.isSelected()){
                gender="Female";
            }
            pst.setString(5, gender);
            pst.setString(6, txtAddress.getText());
            pst.setString(7, txtTpno.getText());
            pst.setString(8, txtEmail.getText());
            pst.setString(9, txtQuaType.getText());
             pst.setString(10, txtInstitute.getText());
            pst.setString(11, txtYearOfComp.getText());

            pst.executeUpdate();
            DefaultTableModel model=(DefaultTableModel)ugTable.getModel();
            model.setRowCount(0);
            showPGstudents();
            JOptionPane.showMessageDialog(null, "Successfully Inserted");
            btnDelete.setVisible(true);
            btnUpdate.setVisible(true);
            txtSearch.setVisible(true);
            lblPGSearch.setVisible(true);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to save");
        }

    }//GEN-LAST:event_btnSaveAddActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed

        try{

            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valCourseReg=comboCourseReg.getSelectedItem().toString();

            String valUgid=txtUgid.getText();
            String valName=txtName.getText();
            SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
            String date=sdf.format(txtDob.getDate());
            String valDob=date;
            if(radioM.isSelected()){
                gender="Male";
            }
            if(radioF.isSelected()){
                gender="Female";
            }
            String valGender=gender;
            String valAddress=txtAddress.getText();
            String valTpno=txtTpno.getText();
            String valEmail=txtEmail.getText();
            String valQua=txtQuaType.getText();
            String valInstitute=txtInstitute.getText();
            String valYr=txtYearOfComp.getText();

            String query="UPDATE pgstudents SET course='"+valCourseReg+"',pgid='"+valUgid+"', name='"+valName+"', dob='"+valDob+"', gender='"+valGender+"', address='"+valAddress+"', tpno='"+valTpno+"', email='"+valEmail+"', quatype='"+valQua+"', institute='"+valInstitute+"',yearcomplete='"+valYr+"' WHERE pgid='"+valUgid+"' ";

            //String query="UPDATE ugstudents SET ugid=?,name=?,dob=?,gender=?,address=?,tpno=?,email=?,alresult=?,rank=? WHERE ugid="+value;
            PreparedStatement pst=con.prepareStatement(query);

            pst.execute();
            DefaultTableModel model=(DefaultTableModel) ugTable.getModel();
            model.setRowCount(0);
            showPGstudents();
            JOptionPane.showMessageDialog(null, "Successfully Updated");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to Update");
        }

    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        int opt=JOptionPane.showConfirmDialog(null, "Are you sure to Delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(opt==0){
            try{

                //String query="insert into ugstudents(ugid,name,dob,gender,address,tpno,email,alresult,rank) values(?,?,?,?,?,?,?,?,?)";
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

                String valUgid=txtUgid.getText();
                String query="delete from ugstudents where pgid='"+valUgid+"' ";
                PreparedStatement pst=con.prepareStatement(query);
                pst.execute();
                DefaultTableModel model=(DefaultTableModel) ugTable.getModel();
                model.setRowCount(0);
                showPGstudents();
                JOptionPane.showMessageDialog(null, "Successfully Deleted");

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Unable to delete");
            }
        }
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnCancel1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCancel1ActionPerformed
        /*  panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelEdit);
        panelBase.repaint();
        panelBase.revalidate();
        */
        btnDelete.setVisible(true);
        btnUpdate.setVisible(true);
        txtSearch.setVisible(true);
        lblPGSearch.setVisible(true);

        txtUgid.setText("");
        txtName.setText("");
        txtDob.setDate(null);
        buttonGroup2.clearSelection();
        comboCourseReg.setSelectedIndex(0);
        txtAddress.setText("");
        txtTpno.setText("");
        txtEmail.setText("");
        txtQuaType.setText("");
        txtYearOfComp.setText("");
        txtSearch.setText("");
        txtInstitute.setText("");

    }//GEN-LAST:event_btnCancel1ActionPerformed

    private void btnConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConfirmActionPerformed

        
        showPGSubjEnroll();

        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valUgid=txtUgidEnroll.getText();
            String sql="SELECT gpa FROM gpa WHERE stuid='"+txtUgidEnroll.getText()+"' ";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            if(comboYear.getSelectedIndex()==3){

                if(rs.next()){
                    txtEnrollGpa.setVisible(true);
                    lblEnrollGpa.setVisible(true);
                    //lblQualified.setVisible(true);
                 //   String setGpa=rs.getString("gpa");
                 //   txtEnrollGpa.setText(setGpa);
                  //  if(Double.parseDouble(txtEnrollGpa.getText())>3.5 && (comboCourse.getSelectedIndex()!=4 && comboCourse.getSelectedIndex()!=5)) JOptionPane.showMessageDialog(null,"Qualified for 4th Year!" );
                  ///  else JOptionPane.showMessageDialog(null,"Not Qualified for 4th Year!" );
                }
            }
            else{
                txtEnrollGpa.setVisible(false);
                lblEnrollGpa.setVisible(false);
                //lblQualified.setVisible(false);
            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to confirm");
        }

        /* try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String val="BCS";
            String sql="SELECT subjcode,subjname,credits,fees FROM subject WHERE subjcode='"+val+"'";
            //PreparedStatement s=con.prepareStatement(query1);

            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            DefaultTableModel model=(DefaultTableModel)tableSubject.getModel();

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        */

        //showSubj();

        /*
        if(comboCourse.getSelectedIndex()==0){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBCS);
            panelRight.repaint();
            panelRight.revalidate();
        }
        else if(comboCourse.getSelectedIndex()==1){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBIS);
            panelRight.repaint();
            panelRight.revalidate();
        }
        else if(comboCourse.getSelectedIndex()==2){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBBM);
            panelRight.repaint();
            panelRight.revalidate();
        }
        else if(comboCourse.getSelectedIndex()==3){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBBA);
            panelRight.repaint();
            panelRight.revalidate();
        }
        else if(comboCourse.getSelectedIndex()==4){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBME);
            panelRight.repaint();
            panelRight.revalidate();
        }
        else if(comboCourse.getSelectedIndex()==5){
            panelRight.removeAll();
            panelRight.repaint();
            panelRight.revalidate();

            panelRight.add(panelBEE);
            panelRight.repaint();
            panelRight.revalidate();
        }
        */

    }//GEN-LAST:event_btnConfirmActionPerformed

    private void comboCourseMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboCourseMouseClicked

    }//GEN-LAST:event_comboCourseMouseClicked

    private void txtUgidEnrollKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtUgidEnrollKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUgidEnrollKeyReleased

    private void tableUGsubjMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableUGsubjMouseClicked

        int i=tableUGsubj.getSelectedRow();
        TableModel model=tableUGsubj.getModel();
        txtUgidEnroll.setText(model.getValueAt(i, 0).toString());
        txtSubjCodeEnroll.setText(model.getValueAt(i, 1).toString());
        txtCredits.setText(model.getValueAt(i, 2).toString());
        txtFees.setText(model.getValueAt(i, 3).toString());

    }//GEN-LAST:event_tableUGsubjMouseClicked

    private void goBackAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_goBackAddActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelFrontUG);
        panelBase.repaint();
        panelBase.revalidate();

    }//GEN-LAST:event_goBackAddActionPerformed

    private void txtSubjCodeEnrollKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSubjCodeEnrollKeyReleased
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valSubjCode=txtSubjCodeEnroll.getText();
            String sql="SELECT * FROM subject WHERE subjcode='"+valSubjCode+"' ";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();

            if(rs.next()){
                // String setUgid=rs.getString("ugid");
                // txt.setText(setUgid);
                // String setSubjCode=rs.getString("subjcode");
                // txtUgid.setText(setSubjCode);

                String setCredits=rs.getString("credits");
                txtCredits.setText(setCredits);
                String setFees=rs.getString("fees");
                txtFees.setText(setFees);
                String setCount=rs.getString("stucount");
                txtC.setText(setCount);

            }
            else{
                txtCredits.setText("");
                txtFees.setText("");
                txtC.setText("");
            }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Invalid subject code");
        }
    }//GEN-LAST:event_txtSubjCodeEnrollKeyReleased

    private void btnEnrollAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnrollAddActionPerformed
        //showUGSubjEnroll();

        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String query="insert into pgsubjectenroll(faculty,course,year,semester,month,pgid,subjcode,credits,fees) values(?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            String faculty;
            faculty=comboFaculty.getSelectedItem().toString();
            pst.setString(1, faculty);
            String course;
            course=comboCourse.getSelectedItem().toString();
            pst.setString(2, course);
            String year;
            year=comboYear.getSelectedItem().toString();
            pst.setString(3, year);
            String semi;
            semi=comboSemester.getSelectedItem().toString();
            pst.setString(4, semi);
            String month;
            month=comboMonth.getSelectedItem().toString();
            pst.setString(5, month);
            pst.setString(6, txtUgidEnroll.getText());
            pst.setString(7, txtSubjCodeEnroll.getText());
            pst.setString(8, txtCredits.getText());
            pst.setString(9, txtFees.getText());

            //  String query3="select stucount from subject where subjcode='"+txtSubjCodeEnroll.getText()+"' ";
            //  PreparedStatement pst3=con.prepareStatement(query3);
            //  pst3.execute();
            //  txtC.setText(query3);

            String valC=txtC.getText();
            int valCint=Integer.parseInt(valC)+1;
            String valCstr=Integer.toString(valCint);
            String query2="UPDATE subject SET stucount='"+valCstr+"' where subjcode='"+txtSubjCodeEnroll.getText()+"' ";
            PreparedStatement pst2=con.prepareStatement(query2);
            pst2.execute();

            //String query="UPDATE ugstudents SET ugid=?,name=?,dob=?,gender=?,address=?,tpno=?,email=?,alresult=?,rank=? WHERE ugid="+value;

            //String query2="UPDATE subject set stucount='"++"'";
            //PreparedStatement pst2=con.prepareStatement(query2);
            //String c=txtC.getText();
            //pst2.setString(1, c); */
            //String v=txtStudentCountValue.getText();
            //int u=Integer.parseInt(v);
            // u++;
            // pst.setString(10, Integer.toString(u));
            pst.executeUpdate();
            //pst2.executeUpdate();
            DefaultTableModel model=(DefaultTableModel)tableUGsubj.getModel();
            model.setRowCount(0);
            showPGSubjEnroll();

            int sum=0;
            for(int i=0;i<tableUGsubj.getRowCount();i++){
                sum=sum+Integer.parseInt(tableUGsubj.getValueAt(i,2).toString());
            }
            txtCalcCredit.setText(Integer.toString(sum));
           
                if(Integer.parseInt(txtCalcCredit.getText())>=12){
                    lblCreditVerify.setVisible(true);
                    lblCreditVerify.setText("Sufficient Credits ");
                    lblCreditVerify.setForeground(Color.green);
                    // JOptionPane.showMessageDialog(null, "Sufficient Credits ");
                    btnEnrollConfirm.setVisible(true);
                }
                else{
                    lblCreditVerify.setVisible(true);
                    lblCreditVerify.setText("Insufficient Credits ");
                    lblCreditVerify.setForeground(Color.red);
                    //JOptionPane.showMessageDialog(null, "Not Sufficient Credits ");
                    btnEnrollConfirm.setVisible(false);
                

                double totfees=0;
                for(int i=0;i<tableUGsubj.getRowCount();i++){
                    totfees=totfees+Double.parseDouble(tableUGsubj.getValueAt(i,3).toString());
                }
                txtCalcFees.setText(Double.toString(totfees));
            }
            JOptionPane.showMessageDialog(null, "Successfully Inserted");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to insert");
        }

        /* try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String query="insert into ugsubjenroll(ugid,subjcode,credits,fees) values(?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            pst.setString(1, txtUgidEnroll.getText());
            pst.setString(2, txtSubjCodeEnroll.getText());
            pst.setString(3, query);

            pst.executeUpdate();
            DefaultTableModel model=(DefaultTableModel)ugTable.getModel();
            model.setRowCount(0);
            showUGSubjEnroll();
            JOptionPane.showMessageDialog(null, "Successfully Inserted");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        */
    }//GEN-LAST:event_btnEnrollAddActionPerformed

    private void btnEnrollDeleteUGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnrollDeleteUGActionPerformed
        int opt=JOptionPane.showConfirmDialog(null, "Are you sure to Delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(opt==0){
            try{

                //String query="insert into ugstudents(ugid,name,dob,gender,address,tpno,email,alresult,rank) values(?,?,?,?,?,?,?,?,?)";
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

                String valUgno=txtUgidEnroll.getText();
                String valsbj=txtSubjCodeEnroll.getText();
                String query="delete from pgsubjectenroll where pgid='"+valUgno+"' and subjcode='"+valsbj+"'  ";
                PreparedStatement pst=con.prepareStatement(query);
                pst.execute();
                DefaultTableModel model=(DefaultTableModel) tableUGsubj.getModel();
                model.setRowCount(0);
                showPGSubjEnroll();
                JOptionPane.showMessageDialog(null, "Successfully Deleted");

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Unable to Delete");
            }
        }
    }//GEN-LAST:event_btnEnrollDeleteUGActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
        tableSubject.setModel(new DefaultTableModel(null,new String[]{"Subject Code","Subject Name","No.of Credits","Fees"}));
        tableUGsubj.setModel(new DefaultTableModel(null,new String[]{"PGID","Subject Code","Credits","Fees"}));

        comboFaculty.setSelectedIndex(0);
        comboCourse.setSelectedIndex(0);
        comboYear.setSelectedIndex(0);
        comboSemester.setSelectedIndex(0);
        comboMonth.setSelectedIndex(0);
        txtUgidEnroll.setText("");
        txtSubjCodeEnroll.setText("");
        txtCredits.setText("");
        txtFees.setText("");
        txtCalcCredit.setText("");
        txtCalcFees.setText("");
        lblCreditVerify.setVisible(false);

    }//GEN-LAST:event_jButton5ActionPerformed

    private void btnEnrollConfirmActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnrollConfirmActionPerformed
        JOptionPane.showMessageDialog(null, "Successfully Enrolled!");

        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelFrontUG);
        panelBase.repaint();
        panelBase.revalidate();

        txtUgidEnroll.setText("");
        txtSubjCodeEnroll.setText("");
        txtCredits.setText("");
        txtFees.setText("");

        tableUGsubj.setModel(new DefaultTableModel(null,new String[]{"PGID","Subject Code","Credits","Fees"}));

        /*   try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            int x=Integer.parseInt(txtC.getText())+1;
            String y=Integer.toString(x);
            String query="UPDATE students SET stucount='"+y+"' WHERE subjcode='"+txtSubjCodeEnroll.getText()+"' ";

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }  */
        /* try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String sql="SELECT stucount FROM subject WHERE subjcode='"+txtSubjCodeEnroll.getText()+"' ";
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            //String sql1="SELECT stucount FROM subject WHERE subjcode='"+txtSubjCodeEnroll.getText()+"' ";
            // String sql2="SELECT subjcode FROM subject ";

            //if(txtSubjCodeEnroll.getText().equalsIgnoreCase(sql2)){
                //String setCount=rs.getString("stucount");
                //txtCount.setText(setName);
                txtStudentCountValue.setText(sql);
                int studentCount=Integer.parseInt(sql);
                //int studentCount=Integer.parseInt(txtStudentCountValue.getText());

                studentCount++;
                String query1="UPDATE subject SET stucount='"+studentCount+"' WHERE subjcode='"+txtSubjCodeEnroll.getText()+"' ";
                pst=con.prepareStatement(query1);
                pst.execute();
                // }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }

        */

    }//GEN-LAST:event_btnEnrollConfirmActionPerformed

    private void txtFeesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFeesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFeesActionPerformed

    private void txtUgidEnrollActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUgidEnrollActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUgidEnrollActionPerformed

    private void ugTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ugTableMouseClicked
        /*        txtUgid.setEditable(false);
        int i=ugTable.getSelectedRow();
        TableModel model=ugTable.getModel();
        txtUgid.setText(model.getValueAt(i, 0).toString());
        txtName.setText(model.getValueAt(i, 1).toString());

        try{
            int srow=ugTable.getSelectedRow();
            Date d=new SimpleDateFormat("yyyy-MM-dd").parse((String)model.getValueAt(srow, 2));
            txtDob.setDate(d);
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }

        String sex=model.getValueAt(i,3).toString();
        if(sex.equals("Male")){
            radioM.setSelected(true);
        }
        else{
            radioF.setSelected(true);
        }
        txtAddress.setText(model.getValueAt(i, 4).toString());
        txtTpno.setText(model.getValueAt(i, 5).toString());
        txtEmail.setText(model.getValueAt(i, 6).toString());
        txtAlresult.setText(model.getValueAt(i, 7).toString());
        txtRank.setText(model.getValueAt(i, 8).toString());
        */
    }//GEN-LAST:event_ugTableMouseClicked

    private void btnGoBackViewUGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoBackViewUGActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelEdit);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_btnGoBackViewUGActionPerformed

    private void btnViewCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewCourseActionPerformed
        showPGstudents();

    }//GEN-LAST:event_btnViewCourseActionPerformed

    private void btnViewClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnViewClearActionPerformed
        ugTable.setModel(new DefaultTableModel(null,new String[]{"PGID","Name","DOB","Gender","Address","TP no","Email","Qualification Type","Institute","Year of Completion"}));
    }//GEN-LAST:event_btnViewClearActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelAddResult);
        panelBase.repaint();
        panelBase.revalidate();

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelViewResult);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelFrontUG);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_jButton9ActionPerformed

    private void txtViewResultUgidKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtViewResultUgidKeyReleased
        viewPgResult();
    }//GEN-LAST:event_txtViewResultUgidKeyReleased

    private void btnCalcGpaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcGpaActionPerformed
        int totCredits=0;
        for(int i=0;i<tableUgResult.getRowCount();i++){
            totCredits+=Integer.parseInt(tableUgResult.getValueAt(i,2).toString());
        }
        //txtCalcCredit.setText(Integer.toString(totCredits));
        int gradeVal=0;
        double gradecredits=0;
        double gpa=0;
        for(int j=0;j<tableUgResult.getRowCount();j++){
            if(tableUgResult.getValueAt(j, 1).toString().equals("A")){
                gradecredits+=4*Double.parseDouble(tableUgResult.getValueAt(j, 2).toString());
            }
            else if(tableUgResult.getValueAt(j, 1).toString().equals("B")){
                gradecredits+=3*Double.parseDouble(tableUgResult.getValueAt(j, 2).toString());
            }
            else if(tableUgResult.getValueAt(j, 1).toString().equals("C")){
                gradecredits+=2*Double.parseDouble(tableUgResult.getValueAt(j, 2).toString());
            }
            else if(tableUgResult.getValueAt(j, 1).toString().equals("D")){
                gradecredits+=1*Double.parseDouble(tableUgResult.getValueAt(j, 2).toString());
            }
            else if(tableUgResult.getValueAt(j, 1).toString().equals("F")){
                gradecredits+=0*Double.parseDouble(tableUgResult.getValueAt(j, 2).toString());
            }
            else{
                gradeVal=0;
                gpa=0;
            }

        }
        gpa=gradecredits/totCredits;
        //txtGpa.setText(Double.toString(gpa));
        txtGC.setText(Double.toString(gradecredits));
        txtTotC.setText(Integer.toString(totCredits));
        txtGpa.setText(Double.toString(Math.round(gpa*100)/100.0));
        // gradeCredits=0;
        //for(int k=0;k<tableUgResult.getRowCount();k++){

            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

                String query1="delete from gpa where stuid='"+txtViewResultUgid.getText()+"'  ";
                PreparedStatement pst1=con.prepareStatement(query1);
                pst1.execute();
                //DefaultTableModel model=(DefaultTableModel) tableUGsubj.getModel();
                //model.setRowCount(0);
                //showUGSubjEnroll();

                String query2="insert into gpa(stuid,gpa) values(?,?)";
                PreparedStatement pst2=con.prepareStatement(query2);

                pst2.setString(1, txtViewResultUgid.getText());
                pst2.setString(2, txtGpa.getText());
                pst2.executeUpdate();

                // String query="UPDATE gpa SET stuid='"+txtViewResultUgid.getText()+"',gpa='"+txtGpa.getText()+"' where stuid='"+txtViewResultUgid.getText()+"' ";
                // PreparedStatement pst=con.prepareStatement(query);

                // pst.execute();

                // JOptionPane.showMessageDialog(null, "GPA Successfully Updated");
            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error in calculating GPA");
            }
    }//GEN-LAST:event_btnCalcGpaActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelMarks);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_jButton10ActionPerformed

    private void btnClearResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearResultActionPerformed
        tableUgResult.setModel(new DefaultTableModel(null,new String[]{"Subject","Grade","Credits"}));
        txtViewResultUgid.setText("");
        txtTotC.setText("");
        txtGC.setText("");
        txtGpa.setText("");
    }//GEN-LAST:event_btnClearResultActionPerformed

    private void txta6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txta6ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txta6ActionPerformed

    private void txta7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txta7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txta7ActionPerformed

    private void txtUgidAddResultKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtUgidAddResultKeyReleased

    }//GEN-LAST:event_txtUgidAddResultKeyReleased

    private void btnCalcFinalGradeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcFinalGradeActionPerformed
        String grade;
        double avgAssign=0;

        int assiTot=0;
        assiTot+=Integer.parseInt(txta1.getText())+Integer.parseInt(txta2.getText())+Integer.parseInt(txta3.getText())+Integer.parseInt(txta4.getText())+Integer.parseInt(txta5.getText())+Integer.parseInt(txta6.getText())+Integer.parseInt(txta7.getText())+Integer.parseInt(txta8.getText())+Integer.parseInt(txta9.getText())+Integer.parseInt(txta10.getText());
        txtTotAssignments.setText(Integer.toString(assiTot));

        if(!txta1.getText().equals("0")) txtNoofAssi.setText("1");
        if(!txta2.getText().equals("0")) txtNoofAssi.setText("2");
        if(!txta3.getText().equals("0")) txtNoofAssi.setText("3");
        if(!txta4.getText().equals("0")) txtNoofAssi.setText("4");
        if(!txta5.getText().equals("0")) txtNoofAssi.setText("5");
        if(!txta6.getText().equals("0")) txtNoofAssi.setText("6");
        if(!txta7.getText().equals("0")) txtNoofAssi.setText("7");
        if(!txta8.getText().equals("0")) txtNoofAssi.setText("8");
        if(!txta9.getText().equals("0")) txtNoofAssi.setText("9");
        if(!txta10.getText().equals("0")) txtNoofAssi.setText("10");

        avgAssign=Integer.parseInt(txtTotAssignments.getText())/Double.parseDouble(txtNoofAssi.getText());
        txtAvgAssi.setText(Double.toString(avgAssign));
        double finalResult=Double.parseDouble(txtExam.getText())*0.7+avgAssign*0.3;
        if(finalResult>=75) grade="A";
        else if(finalResult>=65) grade="B";
        else if(finalResult>=55) grade="C";
        else if(finalResult>=45) grade="D";
        else if(finalResult<45) grade="F";
        else grade="AB";
        txtFinalGrade.setText(grade);

    }//GEN-LAST:event_btnCalcFinalGradeActionPerformed

    private void btnSaveAddResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveAddResultActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String query="insert into pgsubjmarks(pgid,subjcode,credits,a01,a02,a03,a04,a05,a06,a07,a08,a09,a10,exam,grade) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);

            pst.setString(1, txtUgidAddResult.getText());
            pst.setString(2, txtSubjCodeAddResult.getText());
            pst.setString(3, txtAddCredits.getText());
            pst.setString(4, txta1.getText());
            pst.setString(5, txta2.getText());
            pst.setString(6, txta3.getText());
            pst.setString(7, txta4.getText());
            pst.setString(8, txta5.getText());
            pst.setString(9, txta6.getText());
            pst.setString(10, txta7.getText());
            pst.setString(11, txta8.getText());
            pst.setString(12, txta9.getText());
            pst.setString(13, txta10.getText());
            pst.setString(14, txtExam.getText());
            pst.setString(15, txtFinalGrade.getText());

            pst.executeUpdate();
            //DefaultTableModel model=(DefaultTableModel)ugTable.getModel();
            // model.setRowCount(0);
            //showUGstudents();
            JOptionPane.showMessageDialog(null, "Successfully Inserted");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to save Results");
        }
    }//GEN-LAST:event_btnSaveAddResultActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
        panelBase.removeAll();
        panelBase.repaint();
        panelBase.revalidate();

        panelBase.add(panelMarks);
        panelBase.repaint();
        panelBase.revalidate();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void btnGoAddResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGoAddResultActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valUgid1=txtUgidAddResult.getText();
            String valSubj1=txtSubjCodeAddResult.getText();
            String sql="SELECT * FROM ugsubjmarks WHERE ugid='"+valUgid1+"' and subjcode='"+valSubj1+"' ";

            //String val60=txtSubjCodeAddResult.getText();
            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();
            /*
            String sql2="select credits from subject where subjcode='"+valSubj1+"' ";

            ResultSet rs2=pst.executeQuery(sql2);
            txtAddCredits.setText(sql2);
            */
            if(rs.next()){
                String seta1=rs.getString("a01");
                txta1.setText(seta1);
                String seta2=rs.getString("a02");
                txta2.setText(seta2);
                String seta3=rs.getString("a03");
                txta3.setText(seta3);
                String seta4=rs.getString("a04");
                txta4.setText(seta4);
                String seta5=rs.getString("a05");
                txta5.setText(seta5);
                String seta6=rs.getString("a06");
                txta6.setText(seta6);
                String seta7=rs.getString("a07");
                txta7.setText(seta7);
                String seta8=rs.getString("a08");
                txta8.setText(seta8);
                String seta9=rs.getString("a09");
                txta9.setText(seta9);
                String seta10=rs.getString("a10");
                txta10.setText(seta10);
                String setExam=rs.getString("exam");
                txtExam.setText(setExam);
                String setGrade=rs.getString("grade");
                txtFinalGrade.setText(setGrade);

            }
            else{
                txta1.setText("0");
                txta2.setText("0");
                txta3.setText("0");
                txta4.setText("0");
                txta5.setText("0");
                txta6.setText("0");
                txta7.setText("0");
                txta8.setText("0");
                txta9.setText("0");
                txta10.setText("0");
                txtExam.setText("0");
                txtFinalGrade.setText("0");

            }

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to add Results");
        }

        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

            String valSubj1=txtSubjCodeAddResult.getText();
            String sql="SELECT credits FROM subject where subjcode='"+valSubj1+"' ";

            PreparedStatement pst=con.prepareStatement(sql);
            ResultSet rs=pst.executeQuery();

            if(rs.next()){
                String setCreditValue=rs.getString("credits");
                txtAddCredits.setText(setCreditValue);

            }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Invalid credits");
        }

    }//GEN-LAST:event_btnGoAddResultActionPerformed

    private void btnDeleteAddResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteAddResultActionPerformed
        int opt=JOptionPane.showConfirmDialog(null, "Are you sure to Delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(opt==0){
            try{

                //String query="insert into ugstudents(ugid,name,dob,gender,address,tpno,email,alresult,rank) values(?,?,?,?,?,?,?,?,?)";
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

                String val6=txtUgidAddResult.getText();
                String val7=txtSubjCodeAddResult.getText();
                String query="delete from ugsubjmarks where ugid='"+val6+"' and subjcode='"+val7+"'  ";
                PreparedStatement pst=con.prepareStatement(query);
                pst.execute();
                //DefaultTableModel model=(DefaultTableModel) tableUGsubj.getModel();
                //model.setRowCount(0);
                //showUGSubjEnroll();
                JOptionPane.showMessageDialog(null, "Successfully Deleted");

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Unable to delete");
            }
        }
    }//GEN-LAST:event_btnDeleteAddResultActionPerformed

    private void btnUpdateAddResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateAddResultActionPerformed
        try{

            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");

            String valugid= txtUgidAddResult.getText();
            String valsubj=txtSubjCodeAddResult.getText();
            String a1=txta1.getText();
            String a2=txta2.getText();
            String a3=txta3.getText();
            String a4=txta4.getText();
            String a5=txta5.getText();
            String a6=txta6.getText();
            String a7=txta7.getText();
            String a8=txta8.getText();
            String a9=txta9.getText();
            String a10=txta10.getText();
            String exams=txtExam.getText();
            String grd=txtFinalGrade.getText();

            String query="UPDATE ugsubjmarks SET ugid='"+valugid+"',subjcode='"+valsubj+"',a01='"+a1+"',a02='"+a2+"',a03='"+a3+"',a04='"+a4+"',a05='"+a5+"',a06='"+a6+"',a07='"+a7+"',a08='"+a8+"',a09='"+a9+"',a10='"+a10+"',exam='"+exams+"',grade='"+grd+"' where ugid='"+valugid+"' and subjcode='"+valsubj+"' ";

            //String query="UPDATE ugstudents SET ugid=?,name=?,dob=?,gender=?,address=?,tpno=?,email=?,alresult=?,rank=? WHERE ugid="+value;
            PreparedStatement pst=con.prepareStatement(query);

            pst.execute();

            JOptionPane.showMessageDialog(null, "Successfully Updated");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to update");
        }

    }//GEN-LAST:event_btnUpdateAddResultActionPerformed

    private void btnClearAddResultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAddResultActionPerformed
        //assiTot=0;
        txtUgidAddResult.setText("");
        txtSubjCodeAddResult.setText("");
        txta1.setText("");
        txta2.setText("");
        txta3.setText("");
        txta4.setText("");
        txta5.setText("");
        txta6.setText("");
        txta7.setText("");
        txta8.setText("");
        txta9.setText("");
        txta10.setText("");
        txtExam.setText("");
        txtFinalGrade.setText("");
        txtNoofAssi.setText("");
        txtAvgAssi.setText("");
        txtTotAssignments.setText("");
        txtAddCredits.setText("");

    }//GEN-LAST:event_btnClearAddResultActionPerformed

    private void txtEnrollGpaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnrollGpaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnrollGpaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        showSubj();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
         JOptionPane.showMessageDialog(null, "Email successfully sent!");
    }//GEN-LAST:event_jButton4ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Postgraduate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Postgraduate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Postgraduate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Postgraduate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Postgraduate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBack1;
    private javax.swing.JButton btnBackUGfrontpage1;
    private javax.swing.JButton btnCalcFinalGrade;
    private javax.swing.JButton btnCalcGpa;
    private javax.swing.JButton btnCancel1;
    private javax.swing.JButton btnClearAddResult;
    private javax.swing.JButton btnClearResult;
    private javax.swing.JButton btnConfirm;
    private javax.swing.JButton btnDelete;
    private javax.swing.JButton btnDeleteAddResult;
    private javax.swing.JButton btnEnrollAdd;
    private javax.swing.JButton btnEnrollConfirm;
    private javax.swing.JButton btnEnrollDeleteUG;
    private javax.swing.JButton btnEnrollUG1;
    private javax.swing.JButton btnGoAddResult;
    private javax.swing.JButton btnGoBackViewUG;
    private javax.swing.JButton btnNew;
    private javax.swing.JButton btnRegisterStudents1;
    private javax.swing.JButton btnResultsAnalysis1;
    private javax.swing.JButton btnSaveAdd;
    private javax.swing.JButton btnSaveAddResult;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btnUpdateAddResult;
    private javax.swing.JButton btnView1;
    private javax.swing.JButton btnViewClear;
    private javax.swing.JButton btnViewCourse;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> comboCourse;
    private javax.swing.JComboBox<String> comboCourseReg;
    private javax.swing.JComboBox<String> comboFaculty;
    private javax.swing.JComboBox<String> comboMonth;
    private javax.swing.JComboBox<String> comboSemester;
    private javax.swing.JComboBox<String> comboViewCourse;
    private javax.swing.JComboBox<String> comboYear;
    private javax.swing.JButton goBackAdd;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel59;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel60;
    private javax.swing.JLabel jLabel61;
    private javax.swing.JLabel jLabel62;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel64;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JLabel lbl1;
    private javax.swing.JLabel lblCreditVerify;
    private javax.swing.JLabel lblEnrollGpa;
    private javax.swing.JLabel lblPGSearch;
    private javax.swing.JLabel lblUgid;
    private javax.swing.JPanel panelAddResult;
    private javax.swing.JPanel panelBase;
    private javax.swing.JPanel panelEdit;
    private javax.swing.JPanel panelEnroll;
    private javax.swing.JPanel panelFrontUG;
    private javax.swing.JPanel panelMarks;
    private javax.swing.JPanel panelView;
    private javax.swing.JPanel panelViewResult;
    private javax.swing.JRadioButton radioF;
    private javax.swing.JRadioButton radioM;
    private javax.swing.JTable tableSubject;
    private javax.swing.JTable tableUGsubj;
    private javax.swing.JTable tableUgResult;
    private javax.swing.JTextField txtAddCredits;
    private javax.swing.JTextField txtAddress;
    private javax.swing.JLabel txtAvgAssi;
    private javax.swing.JTextField txtC;
    private javax.swing.JTextField txtCalcCredit;
    private javax.swing.JTextField txtCalcFees;
    private javax.swing.JTextField txtCredits;
    private com.toedter.calendar.JDateChooser txtDob;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtEnrollGpa;
    private javax.swing.JTextField txtExam;
    private javax.swing.JTextField txtFees;
    private javax.swing.JTextField txtFinalGrade;
    private javax.swing.JLabel txtGC;
    private javax.swing.JLabel txtGpa;
    private javax.swing.JTextField txtInstitute;
    private javax.swing.JTextField txtName;
    private javax.swing.JLabel txtNoofAssi;
    private javax.swing.JTextField txtQuaType;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtSubjCodeAddResult;
    private javax.swing.JTextField txtSubjCodeEnroll;
    private javax.swing.JLabel txtTotAssignments;
    private javax.swing.JLabel txtTotC;
    private javax.swing.JTextField txtTpno;
    private javax.swing.JTextField txtUgid;
    private javax.swing.JTextField txtUgidAddResult;
    private javax.swing.JTextField txtUgidEnroll;
    private javax.swing.JTextField txtViewResultUgid;
    private javax.swing.JTextField txtYearOfComp;
    private javax.swing.JTextField txta1;
    private javax.swing.JTextField txta10;
    private javax.swing.JTextField txta2;
    private javax.swing.JTextField txta3;
    private javax.swing.JTextField txta4;
    private javax.swing.JTextField txta5;
    private javax.swing.JTextField txta6;
    private javax.swing.JTextField txta7;
    private javax.swing.JTextField txta8;
    private javax.swing.JTextField txta9;
    private javax.swing.JTable ugTable;
    // End of variables declaration//GEN-END:variables
}
