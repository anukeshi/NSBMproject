/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class Lect {
    private String lid,lname,ldob,lgender,lemail,laddress,subjteach;
    private int ltpno;
    private double lsalary; 

     public Lect(String lid, String lname,String ldob,String lgender, String lemail, String laddress,  int ltpno, double lsalary,String subjteach) {
        this.lname = lname;
        this.ldob=ldob;
        this.lgender=lgender;
        this.lemail = lemail;
        this.laddress = laddress;
        this.lid = lid;
        this.ltpno = ltpno;
        this.lsalary = lsalary;
        this.subjteach=subjteach;
    }

    
    
    public String getLid() {
        return lid;
    } 
     
    public String getLname() {
        return lname;
    }

    public String getLemail() {
        return lemail;
    }

    public String getLaddress() {
        return laddress;
    }

    public int getLtpno() {
        return ltpno;
    }

    public double getLsalary() {
        return lsalary;
    }
    public String getSubjteach() {
        return subjteach;
    }

    public String getLdob() {
        return ldob;
    }

    public String getLgender() {
        return lgender;
    }
   
}
