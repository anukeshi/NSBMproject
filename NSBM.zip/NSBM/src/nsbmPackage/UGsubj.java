/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class UGsubj {
    private String subjcode,subjname,subjtype;
    private int credits;
    private double fees;
    
    public UGsubj(String subjcode, String subjname,String subjtype,int credits, double fees) {
        this.subjcode = subjcode;
        this.subjname = subjname;
        this.subjtype = subjtype;
        this.credits = credits;
        this.fees = fees;
    }

    public String getSubjcode() {
        return subjcode;
    }

    public String getSubjname() {
        return subjname;
    }

    public int getCredits() {
        return credits;
    }

    public double getFees() {
        return fees;
    }
    
    public String getSubjtype() {
        return subjtype;
    }

    
}
