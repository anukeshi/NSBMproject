/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.List;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;
import javax.swing.plaf.ColorUIResource;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author User
 */
public class Labsessions extends javax.swing.JFrame {

    String place;
    public Labsessions() {
        this.setResizable(false);
        this.setVisible(true);
        initComponents();
        Toolkit tk=getToolkit();
        this.setSize((int)tk.getScreenSize().getWidth(),(int)tk.getScreenSize().getHeight());
        //showLabs();
        sorts();
        rl1.setVisible(false);
        rl2.setVisible(false);
        rl3.setVisible(false);
        rl4.setVisible(false);
        rl5.setVisible(false);
        rl6.setVisible(false);
        rlab1.setVisible(false);
        rlab2.setVisible(false);
        rlab3.setVisible(false);
        rlab4.setVisible(false);
        rlab5.setVisible(false);
        rlab6.setVisible(false);
        lblLocation.setVisible(false);
        JTableHeader header = tableLab.getTableHeader();
        header.setFont(new Font("Century Gothic", Font.PLAIN, 14));
        JTableHeader header2 = timetable.getTableHeader();
        header2.setFont(new Font("Century Gothic", Font.PLAIN, 16));
        //timetable.setVisible(false);
        timetable.hide();
        
      //  lblStuCount.setVisible(true);
       // txtStuCount.setVisible(true);
      //  lblCountExceeded.setVisible(false);
        
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }
     public ArrayList<Lec> lecList(){
        ArrayList<Lec> lecList=new ArrayList<>();
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           String val1=comboCourse.getSelectedItem().toString();
           String val2=comboYear.getSelectedItem().toString();
           String val3=comboStaff.getSelectedItem().toString();
           String typeClass;
           if(val3.equals("Lecture")){
                typeClass="L";
           }
           else{
                typeClass="P";
           }
           String query1="SELECT * FROM lecs WHERE course='"+val1+"' and year='"+val2+"' and classtype='"+typeClass+"'";
           Statement st=con.createStatement();
           ResultSet rs=st.executeQuery(query1);
           Lec l;
           while(rs.next()){
               l=new Lec(rs.getString("course"),rs.getInt("year"),rs.getString("subjectcode"),rs.getString("staffid"),rs.getInt("stucount"),rs.getString("location"),rs.getString("weekday"),rs.getString("timeslot"),rs.getString("classtype"));
               lecList.add(l);
           }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to view Class Schedule Details");
        }
        return lecList;
     }
     
     public void showLabs(){
        ArrayList<Lec> laList=lecList();
        DefaultTableModel model=(DefaultTableModel) tableLab.getModel();
        
        Object[] row=new Object[9];
        for(int i=0;i<laList.size();i++){
            row[0]=laList.get(i).getCourse();
            row[1]=laList.get(i).getYear();
            row[2]=laList.get(i).getSubjectcode();
            row[3]=laList.get(i).getStaffid();
            row[4]=laList.get(i).getStucount();
            row[5]=laList.get(i).getWeekday();
            row[6]=laList.get(i).getTimeslot();
            row[7]=laList.get(i).getLocation();
            row[8]=laList.get(i).getClasstype();
            model.addRow(row);
        }
    }
     private void sorts(){
         //it will sort the tabel rows in either ascending or decending order when a particular column is selected
         DefaultTableModel model=(DefaultTableModel) tableLab.getModel();
         TableRowSorter<DefaultTableModel> s=new TableRowSorter<DefaultTableModel>(model);
         tableLab.setRowSorter(s);
     }
     private void clear(){
         DefaultTableModel model=(DefaultTableModel) tableLab.getModel();
         model.setRowCount(0);
         
             DefaultTableModel dm=(DefaultTableModel) timetable.getModel();
         dm.setRowCount(0); 
         
     

       
     }
     
     
    /* public class MultiLineTableCellRenderer extends JList<String> implements TableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        //make multi line where the cell value is String[]
        if (value instanceof String[]) {
            setListData((String[]) value);
        }

        //cell backgroud color when selected
        if (isSelected) {
            setBackground(UIManager.getColor("Table.selectionBackground"));
        } else {
            setBackground(UIManager.getColor("Table.background"));
        }

        return this;
    }
}*/
     
     /////////////////////////////////////
     /*
     public class MultiLineTableCellRenderer extends JList<String> implements TableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        //make multi line where the cell value is String[]
        if (value instanceof String[]) {
            setListData((String[]) value);
        }

        //cell backgroud color when selected
        if (isSelected) {
            setBackground(UIManager.getColor("Table.selectionBackground"));
        } else {
            setBackground(UIManager.getColor("Table.background"));
        }

        return this;
    }
}   */
   /////////////////////////////////////////  
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        panelMainBase = new javax.swing.JPanel();
        panelLabBase = new javax.swing.JPanel();
        lblLocation = new javax.swing.JLabel();
        rlab1 = new javax.swing.JRadioButton();
        rlab6 = new javax.swing.JRadioButton();
        btnClearLab = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        rl6 = new javax.swing.JRadioButton();
        comboTimeSlot = new javax.swing.JComboBox<>();
        rlab3 = new javax.swing.JRadioButton();
        lblStaffId = new javax.swing.JLabel();
        rlab4 = new javax.swing.JRadioButton();
        rl2 = new javax.swing.JRadioButton();
        btnBackLabSessions = new javax.swing.JButton();
        rl4 = new javax.swing.JRadioButton();
        comboWeekday = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        comboCourse = new javax.swing.JComboBox<>();
        btnAddLab = new javax.swing.JButton();
        txtIid = new javax.swing.JTextField();
        rlab2 = new javax.swing.JRadioButton();
        rlab5 = new javax.swing.JRadioButton();
        rl1 = new javax.swing.JRadioButton();
        comboYear = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        lblStuCount = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableLab = new javax.swing.JTable();
        btnOk = new javax.swing.JButton();
        comboStaff = new javax.swing.JComboBox<>();
        btnDeleteLab = new javax.swing.JButton();
        rl3 = new javax.swing.JRadioButton();
        rl5 = new javax.swing.JRadioButton();
        txtSubjectCode = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtStuCount = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        timetable = new javax.swing.JTable();
        panelView = new javax.swing.JPanel();
        viewLabsCourse = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        viewLabsYear = new javax.swing.JComboBox<>();
        jButton1 = new javax.swing.JButton();
        txt1 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        panelMainBase.setLayout(new java.awt.CardLayout());

        panelLabBase.setBackground(new java.awt.Color(0, 0, 51));
        panelLabBase.setLayout(null);

        lblLocation.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblLocation.setForeground(new java.awt.Color(240, 240, 240));
        lblLocation.setText("Location ");
        panelLabBase.add(lblLocation);
        lblLocation.setBounds(50, 493, 130, 40);

        rlab1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab1.setForeground(new java.awt.Color(240, 240, 240));
        rlab1.setText("Lab A");
        rlab1.setContentAreaFilled(false);
        panelLabBase.add(rlab1);
        rlab1.setBounds(150, 500, 80, 31);

        rlab6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab6.setForeground(new java.awt.Color(240, 240, 240));
        rlab6.setText("Research Lab");
        rlab6.setContentAreaFilled(false);
        panelLabBase.add(rlab6);
        rlab6.setBounds(150, 690, 200, 31);

        btnClearLab.setBackground(new java.awt.Color(0, 0, 51));
        btnClearLab.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnClearLab.setForeground(new java.awt.Color(153, 255, 153));
        btnClearLab.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/clearBigGrey.png"))); // NOI18N
        btnClearLab.setContentAreaFilled(false);
        btnClearLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearLabActionPerformed(evt);
            }
        });
        panelLabBase.add(btnClearLab);
        btnClearLab.setBounds(1250, 10, 100, 60);

        jLabel9.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(240, 240, 240));
        jLabel9.setText("Weekday");
        panelLabBase.add(jLabel9);
        jLabel9.setBounds(50, 400, 150, 23);

        jLabel6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(240, 240, 240));
        jLabel6.setText("Course");
        panelLabBase.add(jLabel6);
        jLabel6.setBounds(50, 90, 90, 23);

        jLabel1.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(204, 204, 204));
        jLabel1.setText("Class Schedules");
        panelLabBase.add(jLabel1);
        jLabel1.setBounds(470, 10, 300, 40);

        buttonGroup1.add(rl6);
        rl6.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl6.setForeground(new java.awt.Color(240, 240, 240));
        rl6.setText("IRQUE Hall");
        rl6.setContentAreaFilled(false);
        panelLabBase.add(rl6);
        rl6.setBounds(150, 690, 150, 31);

        comboTimeSlot.setBackground(new java.awt.Color(240, 240, 240));
        comboTimeSlot.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboTimeSlot.setForeground(new java.awt.Color(0, 0, 51));
        comboTimeSlot.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8-10", "10-12", "1-3", "3-5" }));
        panelLabBase.add(comboTimeSlot);
        comboTimeSlot.setBounds(150, 440, 160, 40);

        rlab3.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab3.setForeground(new java.awt.Color(240, 240, 240));
        rlab3.setText("Lab C");
        rlab3.setContentAreaFilled(false);
        panelLabBase.add(rlab3);
        rlab3.setBounds(150, 580, 80, 31);

        lblStaffId.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblStaffId.setForeground(new java.awt.Color(240, 240, 240));
        lblStaffId.setText("Staff ID");
        panelLabBase.add(lblStaffId);
        lblStaffId.setBounds(50, 350, 150, 30);

        rlab4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab4.setForeground(new java.awt.Color(240, 240, 240));
        rlab4.setText("3rd Year Lab");
        rlab4.setContentAreaFilled(false);
        panelLabBase.add(rlab4);
        rlab4.setBounds(150, 610, 110, 31);

        buttonGroup1.add(rl2);
        rl2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl2.setForeground(new java.awt.Color(240, 240, 240));
        rl2.setText("Lect Hall 2");
        rl2.setContentAreaFilled(false);
        panelLabBase.add(rl2);
        rl2.setBounds(150, 540, 120, 31);

        btnBackLabSessions.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnBackLabSessions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/greyBack.png"))); // NOI18N
        btnBackLabSessions.setText("<<");
        btnBackLabSessions.setContentAreaFilled(false);
        btnBackLabSessions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBackLabSessionsActionPerformed(evt);
            }
        });
        panelLabBase.add(btnBackLabSessions);
        btnBackLabSessions.setBounds(10, 10, 80, 70);

        buttonGroup1.add(rl4);
        rl4.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl4.setForeground(new java.awt.Color(240, 240, 240));
        rl4.setText("Mini Auditorium");
        rl4.setContentAreaFilled(false);
        panelLabBase.add(rl4);
        rl4.setBounds(150, 610, 170, 31);

        comboWeekday.setBackground(new java.awt.Color(240, 240, 240));
        comboWeekday.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboWeekday.setForeground(new java.awt.Color(0, 0, 51));
        comboWeekday.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Monday", "Tuesday", "Wednesday", "Thursday", "Friday" }));
        panelLabBase.add(comboWeekday);
        comboWeekday.setBounds(150, 390, 160, 40);

        jLabel5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(240, 240, 240));
        jLabel5.setText("Class");
        panelLabBase.add(jLabel5);
        jLabel5.setBounds(50, 190, 90, 23);

        jLabel2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(240, 240, 240));
        jLabel2.setText("Subject");
        panelLabBase.add(jLabel2);
        jLabel2.setBounds(50, 250, 170, 23);

        comboCourse.setBackground(new java.awt.Color(240, 240, 240));
        comboCourse.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboCourse.setForeground(new java.awt.Color(0, 0, 51));
        comboCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BCS", "BIS", "BBM", "BBA", "BME", "BEE", "MCS", "MIS", "MBM", "MBA", "MME", "MEE" }));
        panelLabBase.add(comboCourse);
        comboCourse.setBounds(150, 80, 160, 40);

        btnAddLab.setBackground(new java.awt.Color(0, 0, 51));
        btnAddLab.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnAddLab.setForeground(new java.awt.Color(240, 240, 240));
        btnAddLab.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/greyAdd.png"))); // NOI18N
        btnAddLab.setContentAreaFilled(false);
        btnAddLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddLabActionPerformed(evt);
            }
        });
        panelLabBase.add(btnAddLab);
        btnAddLab.setBounds(360, 260, 60, 60);

        txtIid.setBackground(new java.awt.Color(240, 240, 240));
        txtIid.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtIid.setForeground(new java.awt.Color(0, 0, 51));
        txtIid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIidActionPerformed(evt);
            }
        });
        panelLabBase.add(txtIid);
        txtIid.setBounds(150, 340, 160, 40);

        rlab2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab2.setForeground(new java.awt.Color(240, 240, 240));
        rlab2.setText("Lab B");
        rlab2.setContentAreaFilled(false);
        panelLabBase.add(rlab2);
        rlab2.setBounds(150, 540, 80, 31);

        rlab5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rlab5.setForeground(new java.awt.Color(240, 240, 240));
        rlab5.setText("4th Year Lab");
        rlab5.setContentAreaFilled(false);
        panelLabBase.add(rlab5);
        rlab5.setBounds(150, 650, 240, 31);

        buttonGroup1.add(rl1);
        rl1.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl1.setForeground(new java.awt.Color(240, 240, 240));
        rl1.setText("Lect Hall 1");
        rl1.setContentAreaFilled(false);
        panelLabBase.add(rl1);
        rl1.setBounds(150, 500, 120, 31);

        comboYear.setBackground(new java.awt.Color(240, 240, 240));
        comboYear.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboYear.setForeground(new java.awt.Color(0, 0, 51));
        comboYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        panelLabBase.add(comboYear);
        comboYear.setBounds(150, 130, 160, 40);

        jLabel10.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(240, 240, 240));
        jLabel10.setText("Time Slot");
        panelLabBase.add(jLabel10);
        jLabel10.setBounds(50, 450, 140, 23);

        lblStuCount.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        lblStuCount.setForeground(new java.awt.Color(240, 240, 240));
        lblStuCount.setText("Students");
        panelLabBase.add(lblStuCount);
        lblStuCount.setBounds(50, 290, 100, 40);

        tableLab.setBackground(new java.awt.Color(240, 240, 240));
        tableLab.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        tableLab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course", "Year", "Subject", "Staff ", "Count", "Weekday", "Timeslot", "Location", "Type"
            }
        ));
        tableLab.setRowHeight(30);
        tableLab.setSelectionBackground(new java.awt.Color(102, 102, 102));
        tableLab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableLabMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableLab);
        if (tableLab.getColumnModel().getColumnCount() > 0) {
            tableLab.getColumnModel().getColumn(0).setPreferredWidth(40);
            tableLab.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableLab.getColumnModel().getColumn(2).setPreferredWidth(60);
            tableLab.getColumnModel().getColumn(3).setPreferredWidth(50);
            tableLab.getColumnModel().getColumn(4).setPreferredWidth(30);
            tableLab.getColumnModel().getColumn(5).setPreferredWidth(70);
            tableLab.getColumnModel().getColumn(6).setPreferredWidth(60);
            tableLab.getColumnModel().getColumn(7).setResizable(false);
            tableLab.getColumnModel().getColumn(8).setPreferredWidth(20);
        }

        panelLabBase.add(jScrollPane1);
        jScrollPane1.setBounds(470, 90, 780, 290);

        btnOk.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/greyForward.png"))); // NOI18N
        btnOk.setText("OK");
        btnOk.setContentAreaFilled(false);
        btnOk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOkActionPerformed(evt);
            }
        });
        panelLabBase.add(btnOk);
        btnOk.setBounds(360, 120, 80, 60);

        comboStaff.setBackground(new java.awt.Color(240, 240, 240));
        comboStaff.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        comboStaff.setForeground(new java.awt.Color(0, 0, 51));
        comboStaff.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lecture", "Practical" }));
        comboStaff.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                comboStaffMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                comboStaffMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                comboStaffMousePressed(evt);
            }
        });
        panelLabBase.add(comboStaff);
        comboStaff.setBounds(150, 180, 160, 40);

        btnDeleteLab.setBackground(new java.awt.Color(0, 0, 51));
        btnDeleteLab.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        btnDeleteLab.setForeground(new java.awt.Color(240, 240, 240));
        btnDeleteLab.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/deleteGrey.png"))); // NOI18N
        btnDeleteLab.setContentAreaFilled(false);
        btnDeleteLab.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteLabActionPerformed(evt);
            }
        });
        panelLabBase.add(btnDeleteLab);
        btnDeleteLab.setBounds(350, 330, 80, 60);

        buttonGroup1.add(rl3);
        rl3.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl3.setForeground(new java.awt.Color(240, 240, 240));
        rl3.setText("Lect Hall 3");
        rl3.setContentAreaFilled(false);
        panelLabBase.add(rl3);
        rl3.setBounds(150, 580, 120, 31);

        buttonGroup1.add(rl5);
        rl5.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        rl5.setForeground(new java.awt.Color(240, 240, 240));
        rl5.setText("Auditorium");
        rl5.setContentAreaFilled(false);
        rl5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rl5ActionPerformed(evt);
            }
        });
        panelLabBase.add(rl5);
        rl5.setBounds(150, 650, 130, 31);

        txtSubjectCode.setBackground(new java.awt.Color(240, 240, 240));
        txtSubjectCode.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtSubjectCode.setForeground(new java.awt.Color(0, 0, 51));
        txtSubjectCode.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtSubjectCodeKeyReleased(evt);
            }
        });
        panelLabBase.add(txtSubjectCode);
        txtSubjectCode.setBounds(150, 240, 160, 40);

        jLabel3.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(240, 240, 240));
        jLabel3.setText("Year");
        panelLabBase.add(jLabel3);
        jLabel3.setBounds(50, 130, 80, 40);

        txtStuCount.setBackground(new java.awt.Color(240, 240, 240));
        txtStuCount.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        txtStuCount.setForeground(new java.awt.Color(0, 0, 51));
        panelLabBase.add(txtStuCount);
        txtStuCount.setBounds(150, 290, 160, 40);

        jButton2.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        jButton2.setForeground(new java.awt.Color(240, 240, 240));
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/timetab.png"))); // NOI18N
        jButton2.setText("Time Table");
        jButton2.setContentAreaFilled(false);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        panelLabBase.add(jButton2);
        jButton2.setBounds(770, 390, 220, 60);

        timetable.setFont(new java.awt.Font("Century Gothic", 0, 16)); // NOI18N
        timetable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"8-10", null, null, null, null, null},
                {"10-12", null, null, null, null, null},
                {"1-3", null, null, null, null, null},
                {"3-5", null, null, null, null, null}
            },
            new String [] {
                "Time Slot", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"
            }
        ));
        timetable.setRowHeight(50);
        timetable.setRowMargin(2);
        timetable.setSelectionBackground(new java.awt.Color(102, 102, 102));
        jScrollPane2.setViewportView(timetable);
        if (timetable.getColumnModel().getColumnCount() > 0) {
            timetable.getColumnModel().getColumn(0).setHeaderValue("Time Slot");
            timetable.getColumnModel().getColumn(1).setHeaderValue("Monday");
            timetable.getColumnModel().getColumn(2).setHeaderValue("Tuesday");
            timetable.getColumnModel().getColumn(3).setHeaderValue("Wednesday");
            timetable.getColumnModel().getColumn(4).setHeaderValue("Thursday");
            timetable.getColumnModel().getColumn(5).setHeaderValue("Friday");
        }

        panelLabBase.add(jScrollPane2);
        jScrollPane2.setBounds(470, 460, 780, 250);

        panelMainBase.add(panelLabBase, "card3");

        panelView.setBackground(new java.awt.Color(0, 0, 51));
        panelView.setLayout(null);

        viewLabsCourse.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "BCS", "BIS", "BBM", "BBA", "BME", "BEE", "MCS", "MIS", "MBM", "MBA", "MME", "MEE" }));
        panelView.add(viewLabsCourse);
        viewLabsCourse.setBounds(250, 90, 56, 20);

        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("course");
        panelView.add(jLabel4);
        jLabel4.setBounds(70, 90, 80, 30);

        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("year");
        panelView.add(jLabel7);
        jLabel7.setBounds(70, 130, 80, 30);

        viewLabsYear.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4" }));
        panelView.add(viewLabsYear);
        viewLabsYear.setBounds(250, 130, 56, 20);

        jButton1.setText("go");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        panelView.add(jButton1);
        jButton1.setBounds(470, 100, 70, 50);

        txt1.setText("jTextField1");
        panelView.add(txt1);
        txt1.setBounds(770, 80, 59, 20);

        panelMainBase.add(panelView, "card2");

        getContentPane().add(panelMainBase, "card4");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtIidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIidActionPerformed

    private void btnAddLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddLabActionPerformed
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String query="insert into lecs(course,year,subjectcode,staffid,stucount,location,weekday,timeslot,classtype) values(?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst=con.prepareStatement(query);
            String course,years,classTypes;
            course=comboCourse.getSelectedItem().toString();
            pst.setString(1, course);
            years=comboYear.getSelectedItem().toString();
            
            pst.setString(2, years);
            
           
            
            String laboratory="";
             
            pst.setString(3, txtSubjectCode.getText());
            pst.setString(4,txtIid.getText());
            pst.setString(5,txtStuCount.getText());
            
            
           String place="";
           if(rl1.isSelected()) place+="Lect Hall 1, ";
           if(rl2.isSelected()) place+="Lect Hall 2, ";
           if(rl3.isSelected()) place+="Lect Hall 3, ";
           if(rl4.isSelected()) place+="Mini Auditorium, ";
           if(rl5.isSelected()) place+="Auditorium, ";
           if(rl6.isSelected()) place+="IRQUE Hall, ";
           if(rlab1.isSelected()) place+="Lab A, ";
           if(rlab2.isSelected()) place+="Lab B, ";
           if(rlab3.isSelected()) place+="Lab C, ";
           if(rlab4.isSelected()) place+="3rd Year Lab, ";
           if(rlab5.isSelected()) place+="4th Year Lab, ";
           if(rlab6.isSelected()) place+="Research Lab, ";
           
            pst.setString(6, place);
            String wday;
            wday=comboWeekday.getSelectedItem().toString();
            pst.setString(7, wday);
            String tslot;
            tslot=comboTimeSlot.getSelectedItem().toString();
            pst.setString(8, tslot);
            classTypes=comboStaff.getSelectedItem().toString();
            //pst.setString(9, classTypes);
            if(classTypes.equalsIgnoreCase("Lecture")){
                 pst.setString(9, "L");
            }
            else{
                pst.setString(9, "P");
            }
           
            
           
            pst.executeUpdate();
            DefaultTableModel model=(DefaultTableModel)tableLab.getModel();
            model.setRowCount(0);
            showLabs();
            JOptionPane.showMessageDialog(null, "Successfully Inserted");
            
            
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, "Unable to Insert");
        }
    }//GEN-LAST:event_btnAddLabActionPerformed

    private void btnDeleteLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteLabActionPerformed
        int opt=JOptionPane.showConfirmDialog(null, "Are you sure to Delete?","Delete",JOptionPane.YES_NO_OPTION);
        if(opt==0){
            try{
                Class.forName("com.mysql.jdbc.Driver");
                Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
                String v1=txtSubjectCode.getText();
                //String v2=txtIid.getText();
                /*String v3="";
                 if(rl1.isSelected()) v3="Lect Hall 1";
                if(rl2.isSelected()) v3="Lect Hall 2";
                if(rl3.isSelected()) v3="Lect Hall 3";
                if(rl4.isSelected()) v3="Mini Auditorium";
                if(rl5.isSelected()) v3="Auditorium";
                if(rl6.isSelected()) v3="IRQUE Hall";
                if(rlab1.isSelected()) v3="Lab A";
                if(rlab2.isSelected()) v3="Lab B";
                if(rlab3.isSelected()) v3="Lab C";
                if(rlab4.isSelected()) v3="3rd Year Lab";
                if(rlab5.isSelected()) v3="4th Year Lab";
                if(rlab6.isSelected()) v3="Research Lab";
           */
            String v4=comboWeekday.getSelectedItem().toString();
             String v5=comboTimeSlot.getSelectedItem().toString();
            String v6=comboYear.getSelectedItem().toString();
                
                
                String query="DELETE FROM lecs WHERE subjectcode= '"+v1+"'  and  weekday='"+v4+"' and timeslot='"+v5+"'  ";
                PreparedStatement pst=con.prepareStatement(query);
                pst.execute();
                DefaultTableModel model=(DefaultTableModel) tableLab.getModel();
                model.setRowCount(0);
                showLabs();
                JOptionPane.showMessageDialog(null, "Successfully Deleted");

            }
            catch(Exception e){
                JOptionPane.showMessageDialog(null, "Unable to Delete");
            }
        }
    }//GEN-LAST:event_btnDeleteLabActionPerformed

    private void btnClearLabActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearLabActionPerformed
      // tableLab.setModel(new DefaultTableModel(null,new String[]{"Course","Subject Code","Staff ID","Student Count","Duration","Location","Weekday","Timeslot"}));
        clear();
        txtSubjectCode.setText("");
        txtIid.setText("");
        txtStuCount.setText("");
        rl1.setVisible(false);
        rl2.setVisible(false);
        rl3.setVisible(false);
        rl4.setVisible(false);
        rl5.setVisible(false);
        rl6.setVisible(false);
        rlab1.setVisible(false);
        rlab2.setVisible(false);
        rlab3.setVisible(false);
        rlab4.setVisible(false);
        rlab5.setVisible(false);
        rlab6.setVisible(false);
        comboCourse.setSelectedIndex(0);
        comboStaff.setSelectedIndex(0);
       // txtStuCount.setVisible(false);
        //lblStuCount.setVisible(false);
       // txtStuCount.setBackground(Color.CYAN);
        comboYear.setSelectedIndex(0);
        comboStaff.setSelectedIndex(0);
        buttonGroup1.clearSelection();
        comboWeekday.setSelectedIndex(0);
        comboTimeSlot.setSelectedIndex(0);
        
        
        
        /* try{

            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
            String valCourse=comboCourse.getSelectedItem().toString();
            String valYear=comboYear.getSelectedItem().toString();
            String valSubjCode=txtSubjectCode.getText();
            String valIid=txtIid.getText();
            String valStuCount=txtStuCount.getText();
            //String valDuration=comboDuration.getSelectedItem().toString();

            String place="";
            if(rl1.isSelected()) place+="Lect Hall 1, ";
            if(rl2.isSelected()) place+="Lect Hall 2, ";
            if(rl3.isSelected()) place+="Lect Hall 3, ";
            if(rl4.isSelected()) place+="Mini Auditorium, ";
            if(rl5.isSelected()) place+="Auditorium, ";
            if(rl6.isSelected()) place+="IRQUE Hall, ";
            if(rlab1.isSelected()) place+="Lab A, ";
            if(rlab2.isSelected()) place+="Lab B, ";
            if(rlab3.isSelected()) place+="Lab C, ";
            if(rlab4.isSelected()) place+="3rd Year Lab, ";
            if(rlab5.isSelected()) place+="4th Year Lab, ";
            if(rlab6.isSelected()) place+="Research Lab, ";
            String valLocation=place;

            String valWeekday=comboWeekday.getSelectedItem().toString();
            String valTime=comboTimeSlot.getSelectedItem().toString();
            String valClassType=comboStaff.getSelectedItem().toString();

            String query="UPDATE lecs SET course='"+valCourse+"',year='"+valYear+"',subjectcode='"+valSubjCode+"',staffid='"+valIid+"',stucount='"+valStuCount+"',location='"+valLocation+"',weekday='"+valWeekday+"',timeslot='"+valTime+"',classtype='"+valClassType+"'  WHERE subjectcode= '"+valSubjCode+"'  and  weekday='"+valWeekday+"' and timeslot='"+valTime+"'  ";

            //String query="UPDATE ugstudents SET ugid=?,name=?,dob=?,gender=?,address=?,tpno=?,email=?,alresult=?,rank=? WHERE ugid="+value;
            PreparedStatement pst=con.prepareStatement(query);

            pst.execute();
            DefaultTableModel model=(DefaultTableModel) tableLab.getModel();
            model.setRowCount(0);
            showLabs();
            JOptionPane.showMessageDialog(null, "Successfully Updated");

        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }*/
    }//GEN-LAST:event_btnClearLabActionPerformed

    private void tableLabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableLabMouseClicked

        int i=tableLab.getSelectedRow();
        TableModel model=tableLab.getModel();
        
        
        String courses=model.getValueAt(i,0).toString();
        switch(courses){
            case "BCS":
                comboCourse.setSelectedIndex(0);
                break;
            case "BIS":
                comboCourse.setSelectedIndex(1);
                break;
            case "BBM":
                comboCourse.setSelectedIndex(2);
                break;
            case "BBA":
                comboCourse.setSelectedIndex(3);
                break;
            case "BME":
                comboCourse.setSelectedIndex(4);
                break;
            case "BEE":
                comboCourse.setSelectedIndex(5);
                break;
            case "MCS":
                comboCourse.setSelectedIndex(6);
                break;
            case "MIS":
                comboCourse.setSelectedIndex(7);
                break;
            case "MBM":
                comboCourse.setSelectedIndex(8);
                break;
            case "MBA":
                comboCourse.setSelectedIndex(9);
                break;
            case "MME":
                comboCourse.setSelectedIndex(10);
                break;
            case "MEE":
                comboCourse.setSelectedIndex(11);
                break;
        }
        String years=model.getValueAt(i,1).toString();
        switch(years){
            case "1":
                comboYear.setSelectedIndex(0);
                break;
            case "2":
                comboYear.setSelectedIndex(1);
                break;
            case "3":
                comboYear.setSelectedIndex(2);
                break;
            case "4":
                comboYear.setSelectedIndex(3);
                break;
            
        }
        txtSubjectCode.setText(model.getValueAt(i, 2).toString());
       // txtStuCount.setVisible(false);
        txtIid.setText(model.getValueAt(i, 3).toString());
        txtStuCount.setText(model.getValueAt(i, 4).toString());
       
        
        
        
      
        String days=model.getValueAt(i,5).toString();
        switch(days){
            case "Monday":
                comboWeekday.setSelectedIndex(0);
                break;
            case "Tuesday":
                comboWeekday.setSelectedIndex(1);
                break;
            case "Wednesday":
                comboWeekday.setSelectedIndex(2);
                break;
            case "Thursday":
                comboWeekday.setSelectedIndex(3);
                break;
            case "Friday":
                comboWeekday.setSelectedIndex(4);
                break;
       }
        String tslot=model.getValueAt(i,6).toString();
        switch(tslot){
            case "8-10":
                comboTimeSlot.setSelectedIndex(0);
                break;
            case "10-12":
                comboTimeSlot.setSelectedIndex(1);
                break;
            case "1-3":
                comboTimeSlot.setSelectedIndex(2);
                break;
            case "3-5":
                comboTimeSlot.setSelectedIndex(3);
                break;
           
       }
        
        String types=model.getValueAt(i,8).toString();
        switch(types){
            case "L":
                comboYear.setSelectedIndex(0);
                break;
            case "P":
                comboYear.setSelectedIndex(1);
                break;
          
            
        }
   
    
    }//GEN-LAST:event_tableLabMouseClicked

    private void btnBackLabSessionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBackLabSessionsActionPerformed
        MainMenu m=new MainMenu();
    }//GEN-LAST:event_btnBackLabSessionsActionPerformed

    private void rl5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rl5ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rl5ActionPerformed

    private void txtSubjectCodeKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSubjectCodeKeyReleased
         try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           String valSubjCode=txtSubjectCode.getText();
           String sql="SELECT * FROM subject WHERE subjcode='"+valSubjCode+"' ";
           PreparedStatement pst=con.prepareStatement(sql);
           ResultSet rs=pst.executeQuery();
           
           if(rs.next()){
              // String setUgid=rs.getString("ugid");
              // txt.setText(setUgid);
              // String setSubjCode=rs.getString("subjcode");
              // txtUgid.setText(setSubjCode);
               
               
               String setCount=rs.getString("stucount");
               txtStuCount.setText(setCount);
               
     
               if(Integer.parseInt(txtStuCount.getText())>40 ){
                        
                        txtStuCount.setBackground(Color.red);
                        txtStuCount.setForeground(Color.black);
                        //comboDuration.setSelectedIndex(1);
                      //  JOptionPane.showMessageDialog(null,"Student count has exceeded! \n         Assign more Labs");         
            // UIManager.put("TextField.background",new ColorUIResource(153,255,153));
                   
             }
             else{
                 txtStuCount.setVisible(true);
                 txtStuCount.setBackground(Color.green);
                 txtStuCount.setForeground(Color.BLACK);
                // comboDuration.setSelectedIndex(1);
               //  JOptionPane.showMessageDialog(null,"Student count not exceeded ");
             }
     
         
               
               
               
               
           }
           else{
              txtStuCount.setText("");
              //lblCountExceeded.setText("");
              //txtStuCount.setBackground(Color.white);
           }
           
         }
         catch(Exception e){
            JOptionPane.showMessageDialog(null, "Invalid Subject code");
        }
    }//GEN-LAST:event_txtSubjectCodeKeyReleased

    private void comboStaffMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboStaffMouseClicked
        
    }//GEN-LAST:event_comboStaffMouseClicked

    private void comboStaffMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboStaffMouseEntered
       
    }//GEN-LAST:event_comboStaffMouseEntered

    private void comboStaffMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_comboStaffMousePressed
       
    }//GEN-LAST:event_comboStaffMousePressed

    private void btnOkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOkActionPerformed
        showLabs();
        if(comboStaff.getSelectedIndex()==0){
          lblStaffId.setText("Lecturer ID");
          txtStuCount.setVisible(true);
          lblLocation.setVisible(true);
          //lblCountExceeded.setVisible(false);
        rl1.setVisible(true);
        rl2.setVisible(true);
        rl3.setVisible(true);
        rl4.setVisible(true);
        rl5.setVisible(true);
        rl6.setVisible(true);
        rlab1.setVisible(false);
        rlab2.setVisible(false);
        rlab3.setVisible(false);
        rlab4.setVisible(false);
        rlab5.setVisible(false);
        rlab6.setVisible(false);
      //  lblCountExceeded.setText("");
      }
      else{
          lblStaffId.setText("Instructor ID");
          lblStuCount.setVisible(true);
          lblLocation.setVisible(true);
       //   lblCountEtxtStuCountxceeded.setVisible(true);
        rlab1.setVisible(true);
        rlab2.setVisible(true);
        rlab3.setVisible(true);
        rlab4.setVisible(true);
        rlab5.setVisible(true);
        rlab6.setVisible(true);
        rl1.setVisible(false);
        rl2.setVisible(false);
        rl3.setVisible(false);
        rl4.setVisible(false);
        rl5.setVisible(false);
        rl6.setVisible(false);
      }
     /*    if(Integer.parseInt(txtStuCount.getText())>=40 && (comboStaff.getSelectedIndex()==1)){
               // lblCountExceeded.setVisible(true);
                txtStuCount.setVisible(true);
                //lblCountExceeded.setText("Student count has exceeded! Assign more Labs");
                
                txtStuCount.setBackground(Color.red);
                txtStuCount.setForeground(Color.YELLOW);
                comboDuration.setSelectedIndex(1);
                JOptionPane.showMessageDialog(null,"Student count has exceeded! \n         Assign more Labs");
                   //txtStuCount.setForeground(Color.yellow);
               }
         else  if(Integer.parseInt(txtStuCount.getText())<40 && (comboStaff.getSelectedIndex()==1)){
            //  lblCountExceeded.setVisible(true);
              txtStuCount.setVisible(true);
            // lblCountExceeded.setText("Student count Not exceeded");
            
             txtStuCount.setBackground(Color.green);
             comboDuration.setSelectedIndex(1);
             JOptionPane.showMessageDialog(null,"Student count not exceeded! ");
         }
        //else{
          // txtStuCount.setBackground(Color.white);
         // }
         
         */
         
         /*
         if(comboStaff.getSelectedIndex()==1){
             if(Integer.parseInt(txtStuCount.getText())>40 ){
                 txtStuCount.setVisible(true);
                 txtStuCount.setBackground(Color.red);
                 txtStuCount.setForeground(Color.yellow);
                 comboDuration.setSelectedIndex(1);
                 JOptionPane.showMessageDialog(null,"Student count has exceeded! \n         Assign more Labs");
             }
             else{
                 txtStuCount.setVisible(true);
                 txtStuCount.setBackground(Color.green);
                 txtStuCount.setForeground(Color.yellow);
                 comboDuration.setSelectedIndex(1);
                 JOptionPane.showMessageDialog(null,"Student count not exceeded ");
             }
     
         }
         
      */
    }//GEN-LAST:event_btnOkActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        /*
        try{
           Class.forName("com.mysql.jdbc.Driver");
           Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logininfo","root","");
           
           String val1;
           val1=viewLabsCourse.getSelectedItem().toString();
           String val2;
           val2=viewLabsYear.getSelectedItem().toString();
         
           String query1="SELECT subjectcode FROM lecs where course='"+val1+"' and year='"+val2+"' ";
           Statement st=con.createStatement();
           
           ResultSet rs=st.executeQuery(query1);
           String goody = rs.getString("subjectcode");
           
           String subjCode="";
           String loc="";
           String wdays="";
           String tslots="";
           
           while(rs.next()){
                String subjCode=rs.getString("subjectcode");
                String loc=rs.getString("location");
                String wdays=rs.getString("weekday");
                String tslots=rs.getString("timeslot");
                
                
           // String s="hello";
           // m.setValueAt(s, 1, 1);
            
            
           }
           
           DefaultTableModel m=(DefaultTableModel) timetable.getModel();
           if(goody.equalsIgnoreCase("Monday")){
                m.setValueAt("hello", 0, 0);
            }
          
           
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
        
    
    */

       
        
        
        
        
    
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      //  timetable.setVisible(true);
        String weekdays="";
         String timeslots="";
         String subjcodes="";
         String types="";
          DefaultTableModel m=(DefaultTableModel) timetable.getModel();
          timetable.setVisible(true);
          
       //   DefaultTableModel dm=(DefaultTableModel) timetable.getModel();
        //m.setRowCount(0);
          
          //MultiLineTableCellRenderer renderer = new MultiLineTableCellRenderer();

    //set TableCellRenderer into a specified JTable column class
   // timetable.setDefaultRenderer(String[].class, renderer);
          
        //  int lines = 2;
   // timetable.setRowHeight(timetable.getRowHeight() * lines);
          /////////////////////////
      /*    MultiLineTableCellRenderer renderer = new MultiLineTableCellRenderer();

    //set TableCellRenderer into a specified JTable column class
    timetable.setDefaultRenderer(String[].class, renderer);

    //or, set TableCellRenderer into a specified JTable column
    timetable.getColumnModel().getColumn(2).setCellRenderer(renderer);*/
          ////////////////////////
          
        for(int i=0;i<tableLab.getRowCount();i++){
       
            weekdays=tableLab.getValueAt(i,5).toString();
            timeslots=tableLab.getValueAt(i,6).toString();
            subjcodes=tableLab.getValueAt(i,2).toString();
            types=tableLab.getValueAt(i,8).toString();
            //mytxt.setText(weekdays);
           
            if(weekdays.equalsIgnoreCase("Monday")){
                    if(timeslots.equalsIgnoreCase("8-10")) m.setValueAt(subjcodes+types, 0, 1);
                    if(timeslots.equalsIgnoreCase("10-12")) m.setValueAt(subjcodes+types, 1, 1);
                    if(timeslots.equalsIgnoreCase("1-3"))  m.setValueAt(subjcodes+types, 2, 1);
                    if(timeslots.equalsIgnoreCase("3-5")) m.setValueAt(subjcodes+types, 3, 1);
            }      
            if(weekdays.equalsIgnoreCase("Tuesday")){
                    if(timeslots.equalsIgnoreCase("8-10")) m.setValueAt(subjcodes+types, 0, 2);
                    if(timeslots.equalsIgnoreCase("10-12")) m.setValueAt(subjcodes+types, 1, 2);
                    if(timeslots.equalsIgnoreCase("1-3"))  m.setValueAt(subjcodes+types, 2, 2);
                    if(timeslots.equalsIgnoreCase("3-5")) m.setValueAt(subjcodes+types, 3, 2);
            }      
            if(weekdays.equalsIgnoreCase("Wednesday")){
                    if(timeslots.equalsIgnoreCase("8-10")) m.setValueAt(subjcodes+types, 0, 3);
                    if(timeslots.equalsIgnoreCase("10-12")) m.setValueAt(subjcodes+types, 1, 3);
                    if(timeslots.equalsIgnoreCase("1-3"))  m.setValueAt(subjcodes+types, 2, 3);
                    if(timeslots.equalsIgnoreCase("3-5")) m.setValueAt(subjcodes+types, 3, 3);
            } 
              if(weekdays.equalsIgnoreCase("Thursday")){
                    if(timeslots.equalsIgnoreCase("8-10")) m.setValueAt(subjcodes+types, 0, 4);
                    if(timeslots.equalsIgnoreCase("10-12")) m.setValueAt(subjcodes+types, 1, 4);
                    if(timeslots.equalsIgnoreCase("1-3"))  m.setValueAt(subjcodes+types, 2, 4);
                    if(timeslots.equalsIgnoreCase("3-5")) m.setValueAt(subjcodes+types, 3, 4);
            } 
              if(weekdays.equalsIgnoreCase("Friday")){
                    if(timeslots.equalsIgnoreCase("8-10")) m.setValueAt(subjcodes+types, 0, 5);
                    if(timeslots.equalsIgnoreCase("10-12")) m.setValueAt(subjcodes+types, 1, 5);
                    if(timeslots.equalsIgnoreCase("1-3"))  m.setValueAt(subjcodes+types, 2, 5);
                    if(timeslots.equalsIgnoreCase("3-5")) m.setValueAt(subjcodes+types, 3, 5);
            } 
           
          
            
          
                 
            
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Labsessions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Labsessions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Labsessions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Labsessions.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Labsessions().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddLab;
    private javax.swing.JButton btnBackLabSessions;
    private javax.swing.JButton btnClearLab;
    private javax.swing.JButton btnDeleteLab;
    private javax.swing.JButton btnOk;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> comboCourse;
    private javax.swing.JComboBox<String> comboStaff;
    private javax.swing.JComboBox<String> comboTimeSlot;
    private javax.swing.JComboBox<String> comboWeekday;
    private javax.swing.JComboBox<String> comboYear;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblLocation;
    private javax.swing.JLabel lblStaffId;
    private javax.swing.JLabel lblStuCount;
    private javax.swing.JPanel panelLabBase;
    private javax.swing.JPanel panelMainBase;
    private javax.swing.JPanel panelView;
    private javax.swing.JRadioButton rl1;
    private javax.swing.JRadioButton rl2;
    private javax.swing.JRadioButton rl3;
    private javax.swing.JRadioButton rl4;
    private javax.swing.JRadioButton rl5;
    private javax.swing.JRadioButton rl6;
    private javax.swing.JRadioButton rlab1;
    private javax.swing.JRadioButton rlab2;
    private javax.swing.JRadioButton rlab3;
    private javax.swing.JRadioButton rlab4;
    private javax.swing.JRadioButton rlab5;
    private javax.swing.JRadioButton rlab6;
    private javax.swing.JTable tableLab;
    private javax.swing.JTable timetable;
    private javax.swing.JTextField txt1;
    private javax.swing.JTextField txtIid;
    private javax.swing.JTextField txtStuCount;
    private javax.swing.JTextField txtSubjectCode;
    private javax.swing.JComboBox<String> viewLabsCourse;
    private javax.swing.JComboBox<String> viewLabsYear;
    // End of variables declaration//GEN-END:variables
}
