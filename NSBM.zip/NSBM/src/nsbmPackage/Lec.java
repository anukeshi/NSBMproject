/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class Lec {
    private String course,subjectcode,staffid,location,weekday,timeslot,classtype;

    
    private int year,stucount,duration;

    
   
    
    public Lec(String course,int year,String subjectcode,String staffid,int stucount, String location, String weekday, String timeslot,String classtype) {
        this.subjectcode = subjectcode;
        
        this.course = course;
        this.staffid = staffid;
        this.year = year;
        this.location = location;
        this.weekday = weekday;
        this.timeslot = timeslot;
        this.stucount = stucount;
        this.classtype = classtype;
    }

  public int getYear() {
        return year;
    }

   public String getStaffid() {
        return staffid;
    }
    

    public String getLocation() {
        return location;
    }

    public String getWeekday() {
        return weekday;
    }

    public String getTimeslot() {
        return timeslot;
    }

    public int getStucount() {
        return stucount;
    } 
     
    public String getCourse() {
        return course;
    }

    public String getSubjectcode() {
        return subjectcode;
    }

    
    public String getClasstype() {
        return classtype;
    }

   
}
