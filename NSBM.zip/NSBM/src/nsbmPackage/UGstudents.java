/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

import java.sql.Date;

/**
 *
 * @author User
 */
public class UGstudents {
     private String course,ugid,name,dob,gender,address,email,alresult;
     private int tpno,rank;
    
     
     public UGstudents(String course,String ugid, String name, String dob, String gender, String address, String email, String alresult, int tpno, int rank) {
        this.course=course;
        this.ugid = ugid;
        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.email = email;
        this.alresult = alresult;
        this.tpno = tpno;
        this.rank = rank;
        
    }
    
    public String getCourse() {
        return course;
    }

    public String getUgid() {
        return ugid;
    }

    public String getName() {
        return name;
    }
    
    public String getDob() {
        return dob;
    }
    
    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getAlresult() {
        return alresult;
    }

    public int getTpno() {
        return tpno;
    }

    public int getRank() {
        return rank;
    }

   

    
    
    
}
