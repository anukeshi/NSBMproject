/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class Inst {
    private String iid,iname,idob,igender,iemail,iaddress,isubjteach;
    private int itpno;
    private double isalary; 

    public Inst(String iid, String iname, String idob, String igender, String iemail, String iaddress, String isubjteach, int itpno, double isalary) {
        this.iid = iid;
        this.iname = iname;
        this.idob = idob;
        this.igender = igender;
        this.iemail = iemail;
        this.iaddress = iaddress;
        this.isubjteach = isubjteach;
        this.itpno = itpno;
        this.isalary = isalary;
    }
    

    public String getIid() {
        return iid;
    }

    public String getIname() {
        return iname;
    }

    public String getIdob() {
        return idob;
    }

    public String getIgender() {
        return igender;
    }

    public String getIemail() {
        return iemail;
    }

    public String getIaddress() {
        return iaddress;
    }

    public String getIsubjteach() {
        return isubjteach;
    }

    public int getItpno() {
        return itpno;
    }

    public double getIsalary() {
        return isalary;
    }
}
