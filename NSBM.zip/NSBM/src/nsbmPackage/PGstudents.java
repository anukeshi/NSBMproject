/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class PGstudents {
     private String course,pgid,name,dob,gender,address,email,quatype,institute;
     private int tpno,rank,yearcomplete;

   
     
     public PGstudents(String course,String pgid, String name, String dob, String gender, String address, String email, String quatype, String institute,int tpno,int yearcomplete) {
        this.course=course;
        this.pgid = pgid;
        this.name = name;
        this.dob = dob;
        this.gender = gender;
        this.address = address;
        this.email = email;
        this.quatype=quatype;
        this.institute=institute;
        this.tpno = tpno;
        this.rank = rank;
        this.yearcomplete=yearcomplete;
        
    }
    
    public String getCourse() {
        return course;
    }

    public String getName() {
        return name;
    }
    
    public String getDob() {
        return dob;
    }
    
    public String getGender() {
        return gender;
    }
     public String getPgid() {
        return pgid;
    }

    public String getQuatype() {
        return quatype;
    }

    public String getInstitute() {
        return institute;
    }

    public int getYearcomplete() {
        return yearcomplete;
    }
    

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public int getTpno() {
        return tpno;
    }

}
