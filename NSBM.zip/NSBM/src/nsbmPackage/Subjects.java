/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class Subjects {
    private String course,subjcode,subjname;
    private int year,semester,credits,stucount;
    private double fees;
    
    public Subjects(String course, String subjcode, String subjname, int year, int semester, int credits, int stucount, double fees) {
        this.course = course;
        this.subjcode = subjcode;
        this.subjname = subjname;
        this.year = year;
        this.semester = semester;
        this.credits = credits;
        this.stucount = stucount;
        this.fees = fees;
    }

    public String getCourse() {
        return course;
    }

    public String getSubjcode() {
        return subjcode;
    }

    public String getSubjname() {
        return subjname;
    }

    public int getYear() {
        return year;
    }

    public int getSemester() {
        return semester;
    }

    public int getCredits() {
        return credits;
    }

    public int getStucount() {
        return stucount;
    }

    public double getFees() {
        return fees;
    }

    
}
