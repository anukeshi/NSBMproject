package nsbmPackage;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;

public class MainMenu extends javax.swing.JFrame {

    public MainMenu() {
        this.setResizable(false);
        this.setVisible(true);
        initComponents();
        Toolkit tk=getToolkit();
        this.setSize((int)tk.getScreenSize().getWidth(),(int)tk.getScreenSize().getHeight());
       
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        menuHome = new javax.swing.JMenu();
        menuStudents = new javax.swing.JMenu();
        menuUg = new javax.swing.JMenuItem();
        menuPg = new javax.swing.JMenuItem();
        menuStaff = new javax.swing.JMenu();
        menuLr = new javax.swing.JMenuItem();
        menuIr = new javax.swing.JMenuItem();
        menuClass = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(0, 0, 51));
        setPreferredSize(new java.awt.Dimension(1280, 720));
        getContentPane().setLayout(null);

        jPanel1.setBackground(new java.awt.Color(0, 0, 51));
        jPanel1.setPreferredSize(new java.awt.Dimension(1366, 768));
        jPanel1.setLayout(null);

        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\uniFamily.jpg")); // NOI18N
        jPanel1.add(jLabel1);
        jLabel1.setBounds(470, 230, 760, 410);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(null);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\User\\Desktop\\nsbmL.jpg")); // NOI18N
        jPanel2.add(jLabel2);
        jLabel2.setBounds(0, 0, 310, 160);

        jLabel7.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(102, 102, 102));
        jLabel7.setText("of");
        jPanel2.add(jLabel7);
        jLabel7.setBounds(720, 40, 60, 90);

        jLabel8.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("National School");
        jPanel2.add(jLabel8);
        jLabel8.setBounds(430, 40, 280, 90);

        jLabel6.setFont(new java.awt.Font("Century Gothic", 0, 36)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 153, 0));
        jLabel6.setText("Business Management");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(770, 40, 520, 90);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 0, 1500, 160);

        jLabel3.setFont(new java.awt.Font("Blackadder ITC", 0, 48)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 204, 204));
        jLabel3.setText("exhausts the Mind\"");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(80, 390, 350, 70);

        jLabel4.setFont(new java.awt.Font("Blackadder ITC", 0, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(204, 204, 204));
        jLabel4.setText("\"Learning never ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(100, 330, 290, 80);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nsbmPics/cap.png"))); // NOI18N
        jPanel1.add(jLabel5);
        jLabel5.setBounds(190, 450, 110, 100);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 1690, 1130);

        menuBar.setBackground(new java.awt.Color(153, 255, 153));
        menuBar.setBorder(null);
        menuBar.setPreferredSize(new java.awt.Dimension(350, 35));

        menuHome.setBackground(new java.awt.Color(153, 255, 153));
        menuHome.setForeground(new java.awt.Color(0, 0, 51));
        menuHome.setText("Home");
        menuHome.setContentAreaFilled(false);
        menuHome.setDelay(100);
        menuHome.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuHomeMouseClicked(evt);
            }
        });
        menuBar.add(menuHome);

        menuStudents.setBackground(new java.awt.Color(153, 255, 153));
        menuStudents.setForeground(new java.awt.Color(0, 0, 51));
        menuStudents.setText("Students");
        menuStudents.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuStudents.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuStudentsActionPerformed(evt);
            }
        });

        menuUg.setBackground(new java.awt.Color(153, 255, 153));
        menuUg.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuUg.setForeground(new java.awt.Color(0, 0, 51));
        menuUg.setText("Undergraduate");
        menuUg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuUgActionPerformed(evt);
            }
        });
        menuStudents.add(menuUg);

        menuPg.setBackground(new java.awt.Color(153, 255, 153));
        menuPg.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuPg.setForeground(new java.awt.Color(0, 0, 51));
        menuPg.setText("Postgraduate");
        menuPg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuPgActionPerformed(evt);
            }
        });
        menuStudents.add(menuPg);

        menuBar.add(menuStudents);

        menuStaff.setBackground(new java.awt.Color(153, 255, 153));
        menuStaff.setForeground(new java.awt.Color(0, 0, 51));
        menuStaff.setText("Staffs");
        menuStaff.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N

        menuLr.setBackground(new java.awt.Color(153, 255, 153));
        menuLr.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuLr.setForeground(new java.awt.Color(0, 0, 51));
        menuLr.setText("Lecturer");
        menuLr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuLrActionPerformed(evt);
            }
        });
        menuStaff.add(menuLr);

        menuIr.setBackground(new java.awt.Color(153, 255, 153));
        menuIr.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuIr.setForeground(new java.awt.Color(0, 0, 51));
        menuIr.setText("Instructor");
        menuIr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuIrActionPerformed(evt);
            }
        });
        menuStaff.add(menuIr);

        menuBar.add(menuStaff);

        menuClass.setBackground(new java.awt.Color(153, 255, 153));
        menuClass.setForeground(new java.awt.Color(0, 0, 51));
        menuClass.setText("Classes");
        menuClass.setFont(new java.awt.Font("Century Gothic", 0, 18)); // NOI18N
        menuClass.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menuClassMouseClicked(evt);
            }
        });
        menuClass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuClassActionPerformed(evt);
            }
        });
        menuBar.add(menuClass);

        setJMenuBar(menuBar);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menuStudentsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuStudentsActionPerformed
        
    }//GEN-LAST:event_menuStudentsActionPerformed

    private void menuUgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuUgActionPerformed
        Undergraduate ug=new Undergraduate();
    }//GEN-LAST:event_menuUgActionPerformed

    private void menuPgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuPgActionPerformed
        Postgraduate ps=new Postgraduate();
    }//GEN-LAST:event_menuPgActionPerformed

    private void menuLrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuLrActionPerformed
        Lecturer lec=new Lecturer();
    }//GEN-LAST:event_menuLrActionPerformed

    private void menuIrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuIrActionPerformed
        Instructor ins=new Instructor();
    }//GEN-LAST:event_menuIrActionPerformed

    private void menuClassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuClassActionPerformed
      
    }//GEN-LAST:event_menuClassActionPerformed

    private void menuClassMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuClassMouseClicked
        Labsessions la=new Labsessions();
    }//GEN-LAST:event_menuClassMouseClicked

    private void menuHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menuHomeMouseClicked
        this.hide();
        MainMenu mm=new MainMenu();
    }//GEN-LAST:event_menuHomeMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuClass;
    private javax.swing.JMenu menuHome;
    private javax.swing.JMenuItem menuIr;
    private javax.swing.JMenuItem menuLr;
    private javax.swing.JMenuItem menuPg;
    private javax.swing.JMenu menuStaff;
    private javax.swing.JMenu menuStudents;
    private javax.swing.JMenuItem menuUg;
    // End of variables declaration//GEN-END:variables
}
