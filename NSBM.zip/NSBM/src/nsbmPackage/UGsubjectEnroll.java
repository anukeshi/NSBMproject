/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class UGsubjectEnroll {
    private String faculty,course,month,ugid,subjcode;
    private int year,semester,credits;
    private double fees;

    public String getFaculty() {
        return faculty;
    }

    public String getCourse() {
        return course;
    }

    public String getMonth() {
        return month;
    }

    public int getYear() {
        return year;
    }

    public int getSemester() {
        return semester;
    }

    public String getUgid() {
        return ugid;
    }

    public String getSubjcode() {
        return subjcode;
    }

    public int getCredits() {
        return credits;
    }

    public double getFees() {
        return fees;
    }

    public UGsubjectEnroll(String faculty, String course, String month, int year, int semester,String ugid, String subjcode, int credits, double fees) {
         this.faculty = faculty;
        this.course = course;
        this.month = month;
        this.year = year;
        this.semester = semester;
        this.ugid = ugid;
        this.subjcode = subjcode;
        this.credits = credits;
        this.fees = fees;
    }
}
