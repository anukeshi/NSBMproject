/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class PgViewResult {
    private String subject,finalGrade;
    private int credits;

    public PgViewResult(String subject, String finalGrade,int credits) {
        this.subject = subject;
        this.finalGrade = finalGrade;
        this.credits=credits;
    }

    public String getSubject() {
        return subject;
    }

    public String getFinalGrade() {
        return finalGrade;
    }
    public int getCredits() {
        return credits;
    }
    
}
