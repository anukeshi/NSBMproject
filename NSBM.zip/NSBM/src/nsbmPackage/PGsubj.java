/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package nsbmPackage;

/**
 *
 * @author User
 */
public class PGsubj {
    private String subjcode,subjname;
    private int credits;
    private double fees;

    public String getSubjcode() {
        return subjcode;
    }

    public String getSubjname() {
        return subjname;
    }

    public int getCredits() {
        return credits;
    }

    public double getFees() {
        return fees;
    }

    public PGsubj(String subjcode, String subjname, int credits, double fees) {
        this.subjcode = subjcode;
        this.subjname = subjname;
        this.credits = credits;
        this.fees = fees;
    }
}
